# aitoearn-trae — Agent Plugins 1.0.0 技能包（TRAE / TraeWork）

由 WorkBuddy 专家包 `aitoearn-workbuddy-0.0.4` 复制而来，**功能与技能内容完全一致**，按
[Agent Plugins 1.0.0](https://agent-plugins.org) 规范重新打包，可直接上传到 TRAE / TraeWork。

一句话能力：生成文章、短视频、图文与海报，一键分发抖音、快手、小红书、视频号、Facebook、TikTok 等平台。

## 目录结构

```
aitoearn-growth/
├── plugin.json          # 必填清单（10 个字段，封闭 schema）
├── mcp.json             # 2 个 MCP 服务（stdio 桥接远程端点）
├── skills/              # 14 个技能，每个 skills/<name>/SKILL.md
│   ├── aitoearn-orchestrator/   ← 原 agents/aitoearn.md 降级而来（入口技能）
│   ├── channel-publish/
│   ├── image-creation/
│   ├── image-edit/
│   ├── video-generation/
│   ├── browser-operations/
│   ├── byted-basic-working-principles/
│   ├── byted-mediakit-cloudedit-planner/
│   ├── byted-mediakit-cloudedit-basic/
│   ├── byted-mediakit-asr/
│   ├── byted-audio-continuity/
│   ├── byted-asset-preparation/
│   ├── byted-mediakit-media-understand/
│   └── byted-mediakit-audiogen/
└── scripts/
    ├── aitoearn-bridge.mjs   # stdio ↔ Streamable HTTP 桥
    ├── validate.mjs          # 规范自检
    ├── pack.mjs              # 出两种产物
    ├── selftest.mjs          # 桥接端到端测试（本地 mock，9 项）
    └── rename.mjs            # 换品牌
```

## 与 WorkBuddy 专家包的差异（为什么要改）

| 项 | WorkBuddy 专家包 | 本插件包 |
| --- | --- | --- |
| agent | `agents/aitoearn.md` | **无 agent 概念**，降级为 `skills/aitoearn-orchestrator`，靠 description 触发 |
| 清单 | `.codebuddy-plugin/plugin.json`（自定义字段） | 根 `plugin.json`，仅 10 个标准字段（`additionalProperties: false`） |
| MCP | `.mcp.json`，`type: http` + `x-workbuddy` 私有字段 | 根 `mcp.json`，仅 `$schema` + `mcpServers`，`type: stdio` |
| 鉴权 | `headers.Authorization: Bearer ${AITOEARN_API_KEY}` | **不做 `${VAR}` 展开**，改由 stdio 桥在运行时注入 Bearer |
| 展示字段 | displayName / profession / avatar / quickPrompts / tags | 规范不认，全部移除（如需展示信息放 `extensions`） |

技能正文一字未改，功能保持一致。

## MCP 鉴权

### 技能包内交互式配置（推荐）

入口技能已内置 onboarding 路由：当会话缺少 aitoearn 工具（如 `call_maas_proxy`）或调用返回 `-32001` 时，
助手会主动向用户询问 API Key，并调用本包新增的 `scripts/aitoearn-mcp-setup.mjs` 一键完成注册与验证：

```bash
node scripts/aitoearn-mcp-setup.mjs <API_KEY> [cn|ai]
```

该脚本同时：

1. 把 Key 写入 `~/.aitoearn/config.json`（chmod 600，合并已有内容）——与下方桥接进程的读取约定一致；
2. 把 `aitoearn-cn` / `aitoearn` 服务器（Streamable HTTP + `X-Api-Key` 头）注册进 Trae 用户级 `~/.trae-cn/mcp.json`（合并，保留已有服务器）；
3. 用该 Key 实测 `tools/list` 验证，失败输出诊断（Key 无效 / 站点不匹配 / 网络不通）。

测试可用环境变量重定向两个配置路径：`AITOEARN_CONFIG`、`AITOEARN_MCP_CONFIG`。

### 手动配置（桥接读取顺序）

`mcp.json` 里**不能**写密钥（规范要求）。桥接进程按以下顺序取 key：

1. 环境变量：`AITOEARN_API_KEY`（国际站 aitoearn.ai）/ `AITOEARN_CN_API_KEY`（中国站 aitoearn.cn）
   —— 由客户端进程继承，在 TRAE 的 MCP 环境变量或系统环境里配置。
2. 配置文件（`AITOEARN_CONFIG` 指定路径，默认 `~/.aitoearn/config.json`）：

```json
{ "AITOEARN_API_KEY": "…", "AITOEARN_CN_API_KEY": "…" }
```

也接受 `{ "apiKey": "…" }` 或 `{ "aitoearn": { "apiKey": "…" }, "aitoearn-cn": { "apiKey": "…" } }`。

未配置时桥接仍会启动并在 stderr 提示，调用返回 `-32001` 可读错误，不会静默失败。
排障可开 `AITOEARN_BRIDGE_VERBOSE=1`。

## 上传到 TRAE / TraeWork

两条入口，两种产物都要出：

- **插件包**：zip 根目录就是 `plugin.json`
- **单技能**：zip 根目录就是 `SKILL.md`

```bash
node scripts/validate.mjs   # 0 error / 1 warn（license 待授权确认）
node scripts/selftest.mjs   # 9/9
node scripts/pack.mjs       # 产出 dist/
node scripts/merge-skill.mjs  # 可选：把 14 个技能合成 1 个可上传的技能包
```

产物：

- `dist/aitoearn-growth-0.0.4.zip` —— 插件包
- `dist/skills/<skill>-0.0.4.zip` —— 14 个单技能包

`skills/` 只扫一层，子目录里的 `SKILL.md` 不会被识别；`references/` 只是随行资料，不影响识别。

### 一次上传：合并技能包

若 TRAE 当前环境没有「插件」上传入口（只有「技能」入口，且报错 `Skill package does not contain SKILL.md`），
用 `scripts/merge-skill.mjs` 把 14 个技能折成一个技能包：

```
SKILL.md                      ← 入口技能正文 + 路由表
references/<skill>/SKILL.md   ← 每个子技能原文（含各自的 references/）
```

根目录是 `SKILL.md`，一次上传即可，功能不变。代价是失去"按 description 自动命中单个小技能"的粒度，
改由路由表在包内选择。

## 换品牌

```bash
node scripts/rename.mjs --to trace --url https://trace.example.com/api/ai/agent/mcp
node scripts/validate.mjs && node scripts/pack.mjs
```

## 已知待办

- `license` 暂为 `UNLICENSED`，上游素材授权确认后替换为 SPDX 标识。
- 桥接仅对本地 mock 验证（9/9），未对真实 aitoearn 端点跑 `tools/list`。
- `guide_*` 是"信号工具"，返回空对象，靠厂商前端渲染；TRAE 若不渲染，入口技能里已要求助手把指引写成正文。
