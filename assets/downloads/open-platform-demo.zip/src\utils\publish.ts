import type {
  ChannelAccount,
  ChannelCreatePublishFlowParams,
  ContentDraft,
  Platform,
  PlatformOptionDraft,
  PlatformOptionsDraft,
  PlatformLocalizedText,
  PlatformMetadata,
  PlatformStatus,
  PublishContentInput,
} from '../types'
import { getEnvironmentByRegion, getPlatformRegion, getRegionLabel, type PlatformRegion } from '../config/openPlatform'

export interface PlatformUiMeta {
  platform: Platform
  label: string
  mark: string
  logo: string
  status: PlatformStatus
  authType?: string
  authInstruction?: string
  authSupported: boolean
  publishSupported: boolean
  region: PlatformRegion
  regionSupported: boolean
  pluginOnly: boolean
  titleMax?: number
  titleSupported?: boolean
}

export const platformMeta: Record<Platform, {
  label: string
  mark: string
  logo: string
}> = {
  douyin: {
    label: '抖音',
    mark: 'DY',
    logo: 'https://ai-to-earn.oss-cn-beijing.aliyuncs.com/comment/assets/svgs/plats/douyin.svg',
  },
  xhs: {
    label: '小红书',
    mark: 'XHS',
    logo: 'https://ai-to-earn.oss-cn-beijing.aliyuncs.com/comment/assets/svgs/plats/xhs.svg',
  },
  wxSph: {
    label: '视频号',
    mark: 'SPH',
    logo: 'https://ai-to-earn.oss-cn-beijing.aliyuncs.com/comment/assets/svgs/plats/wx-sph.svg',
  },
  KWAI: {
    label: '快手',
    mark: 'KWAI',
    logo: 'https://ai-to-earn.oss-cn-beijing.aliyuncs.com/comment/assets/svgs/plats/ks.svg',
  },
  youtube: {
    label: 'YouTube',
    mark: 'YT',
    logo: 'https://ai-to-earn.oss-cn-beijing.aliyuncs.com/comment/assets/svgs/plats/youtube.svg',
  },
  wxGzh: {
    label: '公众号',
    mark: 'GZH',
    logo: 'https://ai-to-earn.oss-cn-beijing.aliyuncs.com/comment/assets/svgs/plats/gzh.svg',
  },
  bilibili: {
    label: '哔哩哔哩',
    mark: 'BILI',
    logo: 'https://ai-to-earn.oss-cn-beijing.aliyuncs.com/comment/assets/svgs/plats/bilibili.svg',
  },
  twitter: {
    label: 'X / Twitter',
    mark: 'X',
    logo: 'https://ai-to-earn.oss-cn-beijing.aliyuncs.com/comment/assets/svgs/plats/twitter.svg',
  },
  tiktok: {
    label: 'TikTok',
    mark: 'TT',
    logo: 'https://ai-to-earn.oss-cn-beijing.aliyuncs.com/comment/assets/svgs/plats/tiktok.svg',
  },
  facebook: {
    label: 'Facebook',
    mark: 'FB',
    logo: 'https://ai-to-earn.oss-cn-beijing.aliyuncs.com/comment/assets/svgs/plats/facebook.svg',
  },
  instagram: {
    label: 'Instagram',
    mark: 'IG',
    logo: 'https://ai-to-earn.oss-cn-beijing.aliyuncs.com/comment/assets/svgs/plats/instagram.svg',
  },
  threads: {
    label: 'Threads',
    mark: 'TH',
    logo: 'https://ai-to-earn.oss-cn-beijing.aliyuncs.com/comment/assets/svgs/plats/threads.svg',
  },
  pinterest: {
    label: 'Pinterest',
    mark: 'PIN',
    logo: 'https://ai-to-earn.oss-cn-beijing.aliyuncs.com/comment/assets/svgs/plats/pinterest.svg',
  },
  linkedin: {
    label: 'LinkedIn',
    mark: 'IN',
    logo: 'https://ai-to-earn.oss-cn-beijing.aliyuncs.com/comment/assets/svgs/plats/linkedin.svg',
  },
  google_business: {
    label: 'Google Business',
    mark: 'GBP',
    logo: 'https://cdn.simpleicons.org/google/4285F4',
  },
}

export const supportedPlatforms: Platform[] = [
  'douyin',
  'xhs',
  'wxSph',
  'KWAI',
  'youtube',
  'wxGzh',
  'bilibili',
  'twitter',
  'tiktok',
  'facebook',
  'instagram',
  'threads',
  'pinterest',
  'linkedin',
  'google_business',
]

const supportedPlatformSet = new Set<string>(supportedPlatforms)

const pluginPublishOnlyPlatformSet = new Set<Platform>(['xhs', 'wxSph'])

const titleSupportedPlatformSet = new Set<Platform>([
  'douyin',
  'xhs',
  'wxSph',
  'KWAI',
  'youtube',
  'wxGzh',
  'bilibili',
  'pinterest',
  'linkedin',
])

const platformStatusSet = new Set<string>([
  'hidden',
  'available',
  'unavailable',
  'coming_soon',
])

const platformStatusOrder: Record<PlatformStatus, number> = {
  available: 0,
  unavailable: 1,
  coming_soon: 2,
  hidden: 3,
}

export function isSupportedPlatform(value: string): value is Platform {
  return supportedPlatformSet.has(value)
}

export function isPluginPublishOnlyPlatform(value: string): value is Platform {
  return isSupportedPlatform(value) && pluginPublishOnlyPlatformSet.has(value)
}

export function isDemoPublishSelectableAccount(account: ChannelAccount): account is ChannelAccount & { type: Platform } {
  return account.status === 1
    && isSupportedPlatform(account.type)
    && !isPluginPublishOnlyPlatform(account.type)
}

export function isPublishTitleSupported(platform: Platform | string, metaMap?: Map<Platform, PlatformUiMeta>) {
  if (!isSupportedPlatform(platform)) {
    return false
  }

  const meta = metaMap?.get(platform)
  if (typeof meta?.titleSupported === 'boolean') {
    return meta.titleSupported
  }

  if (typeof meta?.titleMax === 'number') {
    return meta.titleMax > 0
  }

  return titleSupportedPlatformSet.has(platform)
}

function isPlatformStatus(value?: string): value is PlatformStatus {
  return Boolean(value && platformStatusSet.has(value))
}

function getLocalizedText(value?: PlatformLocalizedText) {
  if (!value) {
    return undefined
  }

  return value['zh-CN'] || value.zh || value['en-US'] || Object.values(value).find(Boolean)
}

export function createFallbackPlatformInfos(activeRegion: PlatformRegion = 'domestic'): PlatformUiMeta[] {
  return supportedPlatforms.map((platform) => {
    const meta = platformMeta[platform]
    const region = getPlatformRegion(platform)

    return {
      platform,
      label: meta.label,
      mark: meta.mark,
      logo: meta.logo,
      status: 'available',
      authSupported: true,
      publishSupported: true,
      region,
      regionSupported: region === activeRegion,
      pluginOnly: false,
      titleSupported: titleSupportedPlatformSet.has(platform),
    }
  })
}

export const fallbackPlatformInfos: PlatformUiMeta[] = createFallbackPlatformInfos()

const fallbackPlatformInfoMap = new Map<Platform, PlatformUiMeta>(
  fallbackPlatformInfos.map(meta => [meta.platform, meta]),
)

export function createPlatformMetaMap(items: PlatformUiMeta[]) {
  const map = new Map<Platform, PlatformUiMeta>(items.map(item => [item.platform, item]))
  fallbackPlatformInfos.forEach((item) => {
    if (!map.has(item.platform)) {
      map.set(item.platform, item)
    }
  })
  return map
}

export function getPlatformUiMeta(platform: Platform | string, metaMap?: Map<Platform, PlatformUiMeta>) {
  if (isSupportedPlatform(platform)) {
    return metaMap?.get(platform) || fallbackPlatformInfoMap.get(platform) || fallbackPlatformInfoMap.get('bilibili')!
  }

  return {
    platform: 'bilibili',
    label: platform,
    mark: platform.slice(0, 3).toUpperCase(),
    logo: platformMeta.bilibili.logo,
    status: 'available',
    authSupported: false,
    publishSupported: false,
    region: 'domestic',
    regionSupported: false,
    pluginOnly: false,
    titleSupported: false,
  } satisfies PlatformUiMeta
}

function getOptionalNumber(value: unknown) {
  if (typeof value === 'number') {
    return Number.isFinite(value) ? value : undefined
  }

  if (typeof value === 'string' && value.trim()) {
    const numberValue = Number(value)
    return Number.isFinite(numberValue) ? numberValue : undefined
  }

  return undefined
}

export function normalizePlatformMetadataList(
  items: PlatformMetadata[],
  activeRegion: PlatformRegion = 'domestic',
) {
  const metadataMap = new Map<Platform, { item: PlatformMetadata, index: number }>()

  items.forEach((item, index) => {
    if (isSupportedPlatform(item.platform) && item.status !== 'hidden') {
      metadataMap.set(item.platform, { item, index })
    }
  })

  const normalized = supportedPlatforms
    .map((platform, index): { index: number, meta: PlatformUiMeta } => {
      const source = metadataMap.get(platform)
      const item = source?.item
      const fallback = platformMeta[platform]
      const status = isPlatformStatus(item?.status) ? item.status : 'available'
      const region = getPlatformRegion(platform)
      const pluginOnly = item?.authType?.toLowerCase() === 'plugin'
      const titleMax = getOptionalNumber(item?.contentLimits?.maxTitleLength)

      return {
        index: source?.index ?? index + items.length,
        meta: {
          platform,
          label: getLocalizedText(item?.displayName) || fallback.label,
          mark: fallback.mark,
          logo: item?.logoUrl || fallback.logo,
          status,
          authType: item?.authType,
          authInstruction: getLocalizedText(item?.authInstructions),
          authSupported: item?.capabilities?.auth?.supported !== false,
          publishSupported: item?.capabilities?.publish?.supported !== false,
          region,
          regionSupported: region === activeRegion,
          pluginOnly,
          titleMax,
          titleSupported: titleMax === undefined ? titleSupportedPlatformSet.has(platform) : titleMax > 0,
        },
      }
    })
    .sort((left, right) => {
      return Number(right.meta.regionSupported) - Number(left.meta.regionSupported)
        || Number(left.meta.pluginOnly) - Number(right.meta.pluginOnly)
        || platformStatusOrder[left.meta.status] - platformStatusOrder[right.meta.status]
        || left.index - right.index
    })
    .map(item => item.meta)

  return normalized.length > 0 ? normalized : createFallbackPlatformInfos(activeRegion)
}

export function getPlatformSupportLabel(meta: PlatformUiMeta) {
  if (meta.pluginOnly) {
    return '仅插件支持'
  }

  if (!meta.regionSupported) {
    return `仅${getEnvironmentByRegion(meta.region).label}支持`
  }

  if (meta.status === 'coming_soon') {
    return '即将开放'
  }

  if (meta.status === 'unavailable') {
    return `${getRegionLabel(meta.region)}暂未开放`
  }

  if (!meta.authSupported) {
    return '当前站点未开放授权'
  }

  return '可授权'
}

export function canAuthorizePlatform(meta: PlatformUiMeta) {
  return meta.regionSupported
    && !meta.pluginOnly
    && meta.authSupported
    && meta.status === 'available'
}

export function splitTopics(value: string) {
  return value
    .split(/[,，\n]/)
    .map(topic => topic.trim().replace(/^#/, ''))
    .filter(Boolean)
}

export function buildBody(body: string, topicsText: string) {
  const topics = splitTopics(topicsText)
  const topicLines = topics.map(topic => `#${topic}`)
  return [body.trim(), ...topicLines].filter(Boolean).join('\n')
}

export function inferMediaType(url: string): 'video' | 'image' {
  return /\.(png|jpe?g|webp|gif|avif)(\?.*)?$/i.test(url) ? 'image' : 'video'
}

export function getDefaultPublishAt() {
  const date = new Date(Date.now() + 5000)
  date.setMilliseconds(0)
  return date.toISOString()
}

export function toDateTimeLocalValue(isoValue: string) {
  const date = new Date(isoValue)
  const timezoneOffset = date.getTimezoneOffset() * 60000
  return new Date(date.getTime() - timezoneOffset).toISOString().slice(0, 16)
}

export function fromDateTimeLocalValue(value: string) {
  const date = new Date(value)
  date.setMilliseconds(0)
  return date.toISOString()
}

export function formatCompactTime(value?: string) {
  if (!value) {
    return '待返回'
  }

  return new Intl.DateTimeFormat('zh-CN', {
    month: '2-digit',
    day: '2-digit',
    hour: '2-digit',
    minute: '2-digit',
  }).format(new Date(value))
}

export function getStatusText(status?: number) {
  switch (status) {
    case -1:
      return '发布失败'
    case 0:
      return '等待发布'
    case 1:
      return '已发布'
    case 2:
      return '发布中'
    case 5:
      return '更新失败'
    case 6:
      return '队列中'
    case 7:
      return '平台定时'
    case 8:
      return '等待操作'
    case 9:
      return '已取消'
    default:
      return '已创建'
  }
}

export function isTerminalStatus(status?: number) {
  return status === -1 || status === 1 || status === 5 || status === 7 || status === 8 || status === 9
}

export function getDefaultPlatformOption(platform: Platform, mediaType: ContentDraft['mediaType'] = 'video'): PlatformOptionDraft {
  switch (platform) {
    case 'bilibili':
      return { copyright: '1' }
    case 'facebook':
    case 'instagram':
      return { content_category: mediaType === 'video' ? 'reel' : 'post' }
    case 'youtube':
      return {
        privacyStatus: 'public',
        license: 'youtube',
        notifySubscribers: true,
        embeddable: true,
        selfDeclaredMadeForKids: false,
      }
    case 'tiktok':
      return {
        privacy_level: 'PUBLIC_TO_EVERYONE',
        comment_disabled: false,
        duet_disabled: false,
        stitch_disabled: false,
        brand_disclosure_enabled: false,
        brand_organic_toggle: false,
        brand_content_toggle: false,
      }
    case 'linkedin':
      return {
        visibility: 'PUBLIC',
        distribution: 'MAIN_FEED',
      }
    default:
      return {}
  }
}

export function getPlatformOptionDraft(
  platform: Platform,
  platformOptions: PlatformOptionsDraft,
  mediaType: ContentDraft['mediaType'] = 'video',
) {
  return {
    ...getDefaultPlatformOption(platform, mediaType),
    ...(platformOptions[platform] || {}),
  }
}

function isEmptyOptionValue(value: unknown): boolean {
  if (value === undefined || value === null) {
    return true
  }

  if (typeof value === 'string') {
    return value.trim().length === 0
  }

  if (Array.isArray(value)) {
    return value.length === 0
  }

  if (typeof value === 'object') {
    return Object.keys(value).length === 0
  }

  return false
}

function compactPublishOption(option: Record<string, unknown>) {
  const compacted = Object.fromEntries(
    Object.entries(option).filter(([, value]) => !isEmptyOptionValue(value)),
  )

  return Object.keys(compacted).length > 0 ? compacted : undefined
}

function getStringOption(option: PlatformOptionDraft, key: string, fallback = '') {
  const value = option[key]
  return typeof value === 'string' ? value : fallback
}

function getBooleanOption(option: PlatformOptionDraft, key: string, fallback = false) {
  const value = option[key]
  return typeof value === 'boolean' ? value : fallback
}

function getNumberOption(option: PlatformOptionDraft, key: string) {
  const value = option[key]
  if (typeof value === 'number') {
    return Number.isFinite(value) ? value : undefined
  }
  if (typeof value === 'string' && value.trim()) {
    const parsed = Number(value)
    return Number.isFinite(parsed) ? parsed : undefined
  }
  return undefined
}

function getStringListOption(option: PlatformOptionDraft, key: string) {
  const value = option[key]
  if (Array.isArray(value)) {
    return value.map(item => String(item).trim()).filter(Boolean)
  }
  if (typeof value === 'string') {
    return splitTopics(value)
  }
  return []
}

function getRecordOption(option: PlatformOptionDraft, key: string) {
  const value = option[key]
  return value && typeof value === 'object' && !Array.isArray(value)
    ? value as Record<string, unknown>
    : undefined
}

function getInstagramMediaType(contentDraft: ContentDraft, contentCategory: string) {
  if (contentCategory === 'reel') {
    return 'REELS'
  }

  return contentDraft.mediaType === 'video' ? 'VIDEO' : 'IMAGE'
}

function getTwitterPollOption(option: PlatformOptionDraft) {
  if (!getBooleanOption(option, 'pollEnabled')) {
    return undefined
  }

  const options = getStringListOption(option, 'pollOptions').slice(0, 4)
  const durationMinutes = getNumberOption(option, 'pollDurationMinutes') || 1440

  return compactPublishOption({
    options,
    duration_minutes: durationMinutes,
  })
}

function getWxSphPoiInfo(option: PlatformOptionDraft) {
  const poiId = getStringOption(option, 'poiId').trim()
  const poiName = getStringOption(option, 'poiName').trim()
  const poiAddress = getStringOption(option, 'poiAddress').trim()

  if (!poiId && !poiName && !poiAddress) {
    return undefined
  }

  return compactPublishOption({
    poiId,
    poiName,
    poiAddress,
  })
}

function getWxSphActivity(option: PlatformOptionDraft) {
  const eventTopicId = getStringOption(option, 'eventTopicId').trim()
  const eventName = getStringOption(option, 'eventName').trim()

  if (!eventTopicId && !eventName) {
    return undefined
  }

  return compactPublishOption({
    eventTopicId,
    eventName,
  })
}

export function buildPlatformPublishOption(
  platform: Platform,
  option: PlatformOptionDraft,
  contentDraft: ContentDraft,
) {
  switch (platform) {
    case 'bilibili': {
      const copyright = getNumberOption(option, 'copyright') || 1
      return compactPublishOption({
        tid: getNumberOption(option, 'tid'),
        copyright,
        source: copyright === 2 ? getStringOption(option, 'source').trim() : '',
      })
    }
    case 'facebook': {
      return compactPublishOption({
        content_category: contentDraft.mediaType === 'video' ? 'reel' : getStringOption(option, 'content_category', 'post'),
      })
    }
    case 'instagram': {
      const contentCategory = contentDraft.mediaType === 'video' ? 'reel' : getStringOption(option, 'content_category', 'post')
      return compactPublishOption({
        content_category: contentCategory,
        media_type: getStringOption(option, 'media_type') || getInstagramMediaType(contentDraft, contentCategory),
        alt_text: getStringOption(option, 'alt_text').trim(),
        location_id: getStringOption(option, 'location_id').trim(),
      })
    }
    case 'youtube':
      return compactPublishOption({
        privacyStatus: getStringOption(option, 'privacyStatus', 'public'),
        license: getStringOption(option, 'license', 'youtube'),
        categoryId: getStringOption(option, 'categoryId').trim(),
        notifySubscribers: getBooleanOption(option, 'notifySubscribers', true),
        embeddable: getBooleanOption(option, 'embeddable', true),
        selfDeclaredMadeForKids: getBooleanOption(option, 'selfDeclaredMadeForKids'),
      })
    case 'pinterest':
      return compactPublishOption({
        boardId: getStringOption(option, 'boardId').trim(),
        coverImageUrl: getStringOption(option, 'coverImageUrl').trim() || (contentDraft.mediaType === 'video' ? contentDraft.coverUrl.trim() : ''),
        link: getStringOption(option, 'link').trim(),
        altText: getStringOption(option, 'altText').trim(),
      })
    case 'tiktok':
      return compactPublishOption({
        privacy_level: getStringOption(option, 'privacy_level', 'PUBLIC_TO_EVERYONE'),
        disable_comment: getBooleanOption(option, 'comment_disabled'),
        disable_duet: getBooleanOption(option, 'duet_disabled'),
        disable_stitch: getBooleanOption(option, 'stitch_disabled'),
        brand_organic_toggle: getBooleanOption(option, 'brand_organic_toggle'),
        brand_content_toggle: getBooleanOption(option, 'brand_content_toggle'),
      })
    case 'threads':
      return compactPublishOption({
        reply_control: getStringOption(option, 'reply_control').trim(),
        location_id: getStringOption(option, 'location_id').trim(),
        alt_text: getStringOption(option, 'alt_text').trim(),
        topic_tag: getStringOption(option, 'topic_tag').trim(),
        link_attachment_url: getStringOption(option, 'link_attachment_url').trim(),
      })
    case 'twitter':
      return compactPublishOption({
        reply_settings: getStringOption(option, 'replySettings').trim(),
        poll: getTwitterPollOption(option),
        made_with_ai: getBooleanOption(option, 'madeWithAi'),
        alt_text: getStringOption(option, 'altText').trim(),
      })
    case 'xhs': {
      const origin = getNumberOption(option, 'userDeclarationOrigin')
      return compactPublishOption({
        userDeclarationBind: origin ? { origin } : undefined,
      })
    }
    case 'wxSph':
      return compactPublishOption({
        poiInfo: getWxSphPoiInfo(option),
        activity: getWxSphActivity(option),
        isOriginal: getBooleanOption(option, 'isOriginal'),
      })
    case 'wxGzh':
      return compactPublishOption({
        author: getStringOption(option, 'author').trim(),
        digest: getStringOption(option, 'digest').trim(),
        open_comment: getBooleanOption(option, 'open_comment') ? 1 : undefined,
        only_fans_can_comment: getBooleanOption(option, 'only_fans_can_comment') ? 1 : undefined,
        showCoverPic: getBooleanOption(option, 'showCoverPic'),
        sourceUrl: getStringOption(option, 'sourceUrl').trim(),
      })
    case 'douyin':
      return compactPublishOption({
        shareId: getStringOption(option, 'shareId').trim(),
        hashtag_list: getStringListOption(option, 'hashtag_list'),
        short_title: getStringOption(option, 'short_title').trim(),
        custom_cover_image_url: getStringOption(option, 'custom_cover_image_url').trim(),
        cover_tsp: getNumberOption(option, 'cover_tsp'),
        download_type: getNumberOption(option, 'download_type'),
        private_status: getNumberOption(option, 'private_status'),
      })
    case 'KWAI':
      return compactPublishOption({
        cover: getStringOption(option, 'cover').trim(),
        photo_topic: getStringOption(option, 'photo_topic').trim(),
        stereo_type: getStringOption(option, 'stereo_type').trim(),
        merchant_product_id: getStringOption(option, 'merchant_product_id').trim(),
      })
    case 'linkedin':
      return compactPublishOption({
        visibility: getStringOption(option, 'visibility', 'PUBLIC'),
        authorUrn: getStringOption(option, 'authorUrn').trim(),
        distribution: getStringOption(option, 'distribution', 'MAIN_FEED'),
        commentary: getStringOption(option, 'commentary').trim(),
        accountType: getStringOption(option, 'accountType').trim(),
      })
    case 'google_business':
      return undefined
    default:
      return undefined
  }
}

export function buildPublishPayload(
  contentDraft: ContentDraft,
  selectedAccounts: ChannelAccount[],
  platformOptions: PlatformOptionsDraft,
  platformMetaMap?: Map<Platform, PlatformUiMeta>,
): ChannelCreatePublishFlowParams {
  const mediaType = contentDraft.mediaType || inferMediaType(contentDraft.mediaUrl)
  const body = buildBody(contentDraft.body, contentDraft.topics)
  const publishAccounts = selectedAccounts.filter(isDemoPublishSelectableAccount)
  const includeBaseTitle = publishAccounts.every(account => isPublishTitleSupported(account.type, platformMetaMap))
  const content = buildPublishContent(contentDraft, mediaType, body, includeBaseTitle)

  return {
    content,
    publishAt: contentDraft.publishAt,
    context: mediaType === 'video'
      ? {
          type: 'video',
          videoUrl: contentDraft.mediaUrl.trim(),
          source: 'web',
        }
      : {
          type: 'image_text',
          imgUrlList: [contentDraft.mediaUrl.trim()],
          source: 'web',
        },
    items: publishAccounts.map((account) => {
      const platform = account.type
      const option = buildPlatformPublishOption(
        platform,
        getPlatformOptionDraft(platform, platformOptions, mediaType),
        { ...contentDraft, mediaType },
      )
      const item = {
        accountId: account.id,
        platform,
        overrides: buildPublishContent(
          contentDraft,
          mediaType,
          body,
          isPublishTitleSupported(platform, platformMetaMap),
        ),
      }

      return option ? { ...item, option } : item
    }),
  }
}

function buildPublishContent(
  contentDraft: ContentDraft,
  mediaType: ContentDraft['mediaType'],
  body: string,
  includeTitle: boolean,
): PublishContentInput {
  return {
    ...(includeTitle ? { title: contentDraft.title.trim() } : {}),
    body,
    media: [
      {
        url: contentDraft.mediaUrl.trim(),
        metadata: { type: mediaType },
      },
    ],
    ...(contentDraft.coverUrl.trim()
      ? {
          cover: {
            url: contentDraft.coverUrl.trim(),
            metadata: { type: 'image' },
          },
        }
      : {}),
  }
}

export function validateBeforePublish(
  apiKey: string,
  contentDraft: ContentDraft,
  selectedAccounts: ChannelAccount[],
  platformOptions: PlatformOptionsDraft,
  platformMetaMap?: Map<Platform, PlatformUiMeta>,
) {
  if (!apiKey.trim()) {
    return '请先填写 X-Api-Key'
  }

  if (selectedAccounts.length === 0) {
    return '请选择至少一个账号'
  }

  const publishAccounts = selectedAccounts.filter(isDemoPublishSelectableAccount)
  const titleRequired = publishAccounts.some(account => isPublishTitleSupported(account.type, platformMetaMap))

  if (titleRequired && !contentDraft.title.trim()) {
    return '请填写标题'
  }

  if (!contentDraft.body.trim()) {
    return '请填写正文'
  }

  if (!contentDraft.mediaUrl.trim()) {
    return '请上传媒体或填写媒体 URL'
  }

  for (const account of selectedAccounts) {
    if (!isSupportedPlatform(account.type)) {
      continue
    }

    if (isPluginPublishOnlyPlatform(account.type)) {
      return `${platformMeta[account.type].label} 是插件发布平台，demo 不支持发布`
    }

    const option = getPlatformOptionDraft(account.type, platformOptions, contentDraft.mediaType)

    if (account.type === 'bilibili' && !Number(option.tid)) {
      return 'B 站需要选择分区'
    }

    if (account.type === 'bilibili' && Number(option.copyright || 1) === 2 && !getStringOption(option, 'source').trim()) {
      return 'B 站转载内容需要填写来源'
    }

    if (account.type === 'youtube' && !getStringOption(option, 'categoryId').trim()) {
      return 'YouTube 需要选择视频分类'
    }

    if (account.type === 'pinterest' && !getStringOption(option, 'boardId').trim()) {
      return 'Pinterest 需要选择 Board'
    }

    if (account.type === 'twitter' && getBooleanOption(option, 'pollEnabled')) {
      const pollOptions = getStringListOption(option, 'pollOptions')
      const durationMinutes = getNumberOption(option, 'pollDurationMinutes') || 0
      if (pollOptions.length < 2) {
        return 'X / Twitter 投票至少需要两个选项'
      }
      if (pollOptions.some(item => item.length > 25) || durationMinutes < 5 || durationMinutes > 10080) {
        return 'X / Twitter 投票选项需小于 25 字，持续时间需为 5 到 10080 分钟'
      }
      if (contentDraft.mediaUrl.trim()) {
        return 'X / Twitter 投票不能和媒体一起发布'
      }
    }
  }

  return ''
}
