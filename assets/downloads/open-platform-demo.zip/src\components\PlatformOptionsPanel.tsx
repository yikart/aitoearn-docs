import type {
  ChannelAccount,
  ContentDraft,
  Platform,
  PlatformOptionDraft,
  PlatformOptionsDraft,
  PublishOptionValueItem,
} from '../types'
import type { PlatformUiMeta } from '../utils/publish'
import type { ReactNode } from 'react'
import { Check, GearSix, SlidersHorizontal, WarningCircle } from '@phosphor-icons/react'
import { useEffect, useId, useMemo, useState } from 'react'
import { getPlatformOptionDraft, getPlatformUiMeta } from '../utils/publish'
import { Badge } from './ui/badge'
import { Input } from './ui/input'
import { Label } from './ui/label'
import { Textarea } from './ui/textarea'

export interface PublishOptionValuesState {
  items: PublishOptionValueItem[]
  loading: boolean
  error: string
}

interface PlatformOptionsPanelProps {
  selectedAccounts: ChannelAccount[]
  contentDraft: ContentDraft
  platformOptions: PlatformOptionsDraft
  platformMetaMap: Map<Platform, PlatformUiMeta>
  optionValues: Record<string, PublishOptionValuesState>
  onChange: (platform: Platform, patch: PlatformOptionDraft) => void
  onLoadOptionValues: (accountId: string, field: string, params?: Record<string, string>) => void
}

interface OptionFieldProps {
  label: string
  detail?: string
  children: ReactNode
}

interface OptionItem {
  value: string
  label: string
  disabled?: boolean
  depth?: number
}

interface PlatformOptionCardProps {
  platform: Platform
  accounts: ChannelAccount[]
  contentDraft: ContentDraft
  platformOptions: PlatformOptionsDraft
  platformMetaMap: Map<Platform, PlatformUiMeta>
  optionValues: Record<string, PublishOptionValuesState>
  onChange: (platform: Platform, patch: PlatformOptionDraft) => void
  onLoadOptionValues: (accountId: string, field: string, params?: Record<string, string>) => void
}

const inputClassName = 'h-10'

const selectClassName = 'h-10 w-full rounded-md border border-input-border bg-card px-3 text-sm text-foreground shadow-[inset_0_1px_2px_oklch(0.35_0.03_286_/_0.08)] outline-none transition-[border-color,box-shadow,background] hover:border-primary/40 focus-visible:border-ring focus-visible:bg-background focus-visible:ring-[3px] focus-visible:ring-ring/30 disabled:cursor-not-allowed disabled:opacity-50'

const checkboxClassName = 'size-4 rounded border border-input-border accent-[var(--brand-purple)]'

const youtubeCategoryParams = { regionCode: 'US' }

export function getPublishOptionValuesKey(accountId: string, field: string, params?: Record<string, string>) {
  const query = params
    ? new URLSearchParams(Object.entries(params).sort(([left], [right]) => left.localeCompare(right))).toString()
    : ''

  return `${accountId}:${field}:${query}`
}

export function PlatformOptionsPanel({
  selectedAccounts,
  contentDraft,
  platformOptions,
  platformMetaMap,
  optionValues,
  onChange,
  onLoadOptionValues,
}: PlatformOptionsPanelProps) {
  const platformGroups = useMemo(() => {
    const map = new Map<Platform, ChannelAccount[]>()
    selectedAccounts.forEach((account) => {
      const platform = account.type
      if (!platformMetaMap.has(platform as Platform)) {
        return
      }
      const typedPlatform = platform as Platform
      map.set(typedPlatform, [...(map.get(typedPlatform) || []), account])
    })
    return [...map.entries()]
  }, [platformMetaMap, selectedAccounts])
  const [activePlatform, setActivePlatform] = useState('')
  const activeGroup = platformGroups.find(([platform]) => platform === activePlatform) || platformGroups[0]

  useEffect(() => {
    if (!platformGroups.some(([platform]) => platform === activePlatform)) {
      setActivePlatform(platformGroups[0]?.[0] || '')
    }
  }, [activePlatform, platformGroups])

  if (platformGroups.length === 0) {
    return (
      <div className="rounded-md border border-dashed border-border bg-muted/25 p-4 text-sm text-muted-foreground">
        选择账号后可配置各平台发布参数。
      </div>
    )
  }

  return (
    <div className="grid gap-3">
      <div className="flex flex-wrap gap-2 rounded-lg border border-border bg-muted/25 p-2" role="tablist" aria-label="平台参数">
        {platformGroups.map(([platform, accounts]) => {
          const meta = getPlatformUiMeta(platform, platformMetaMap)
          const active = activeGroup?.[0] === platform
          return (
            <button
              key={platform}
              type="button"
              role="tab"
              aria-selected={active}
              className={`inline-flex h-8 min-w-0 items-center gap-2 rounded-md border px-2.5 text-xs font-medium transition ${
                active
                  ? 'border-primary/45 bg-primary/10 text-foreground shadow-sm'
                  : 'border-border bg-card text-muted-foreground hover:border-primary/35 hover:bg-card hover:text-foreground'
              }`}
              onClick={() => setActivePlatform(platform)}
            >
              <PlatformTabMark meta={meta} />
              <span className="min-w-0 truncate">{meta.label}</span>
              <span className="rounded-sm bg-muted px-1.5 py-0.5 text-[10px] text-muted-foreground">
                {accounts.length}
              </span>
            </button>
          )
        })}
      </div>

      {activeGroup ? (
        <PlatformOptionCard
          key={activeGroup[0]}
          platform={activeGroup[0]}
          accounts={activeGroup[1]}
          contentDraft={contentDraft}
          platformOptions={platformOptions}
          platformMetaMap={platformMetaMap}
          optionValues={optionValues}
          onChange={onChange}
          onLoadOptionValues={onLoadOptionValues}
        />
      ) : null}
    </div>
  )
}

function PlatformOptionCard({
  platform,
  accounts,
  contentDraft,
  platformOptions,
  platformMetaMap,
  optionValues,
  onChange,
  onLoadOptionValues,
}: PlatformOptionCardProps) {
  const meta = getPlatformUiMeta(platform, platformMetaMap)
  const option = getPlatformOptionDraft(platform, platformOptions, contentDraft.mediaType)
  const account = accounts[0]

  return (
    <section className="overflow-hidden rounded-lg border border-border bg-card shadow-sm">
      <div className="flex items-start justify-between gap-3 border-b border-border bg-muted/25 p-3">
        <div className="flex min-w-0 items-center gap-3">
          <PlatformLogo meta={meta} />
          <div className="min-w-0">
            <div className="flex flex-wrap items-center gap-2">
              <h3 className="text-sm font-semibold text-foreground">{meta.label}</h3>
              <Badge variant="outline" className="bg-card px-2 py-0.5">{accounts.length} 个账号</Badge>
            </div>
            <p className="mt-0.5 truncate text-xs text-muted-foreground">
              {accounts.map(item => item.nickname || item.uid).join('、')}
            </p>
          </div>
        </div>
        <SlidersHorizontal className="mt-1 size-4 shrink-0 text-muted-foreground" weight="bold" />
      </div>

      <div className="grid gap-3 p-3">
        <PlatformOptionFields
          platform={platform}
          account={account}
          contentDraft={contentDraft}
          option={option}
          optionValues={optionValues}
          onChange={patch => onChange(platform, patch)}
          onLoadOptionValues={onLoadOptionValues}
        />
      </div>
    </section>
  )
}

function PlatformOptionFields({
  platform,
  account,
  contentDraft,
  option,
  optionValues,
  onChange,
  onLoadOptionValues,
}: {
  platform: Platform
  account: ChannelAccount
  contentDraft: ContentDraft
  option: PlatformOptionDraft
  optionValues: Record<string, PublishOptionValuesState>
  onChange: (patch: PlatformOptionDraft) => void
  onLoadOptionValues: (accountId: string, field: string, params?: Record<string, string>) => void
}) {
  const bilibiliState = optionValues[getPublishOptionValuesKey(account.id, 'tid')]
  const youtubeState = optionValues[getPublishOptionValuesKey(account.id, 'categoryId', youtubeCategoryParams)]
  const pinterestState = optionValues[getPublishOptionValuesKey(account.id, 'boardId')]
  const bilibiliOptions = useMemo(() => flattenOptionItems(bilibiliState?.items || []), [bilibiliState?.items])
  const youtubeOptions = useMemo(() => mapOptionItems(youtubeState?.items || []), [youtubeState?.items])
  const pinterestOptions = useMemo(() => mapOptionItems(pinterestState?.items || []), [pinterestState?.items])

  useEffect(() => {
    if (platform === 'bilibili' && !bilibiliState) {
      onLoadOptionValues(account.id, 'tid')
    }
  }, [account.id, bilibiliState, onLoadOptionValues, platform])

  useEffect(() => {
    if (platform === 'youtube' && !youtubeState) {
      onLoadOptionValues(account.id, 'categoryId', youtubeCategoryParams)
    }
  }, [account.id, onLoadOptionValues, platform, youtubeState])

  useEffect(() => {
    if (platform === 'pinterest' && !pinterestState) {
      onLoadOptionValues(account.id, 'boardId')
    }
  }, [account.id, onLoadOptionValues, pinterestState, platform])

  useEffect(() => {
    if (platform === 'bilibili' && !asString(option.tid) && bilibiliOptions.length > 0) {
      const first = bilibiliOptions.find(item => !item.disabled)?.value
      if (first) {
        onChange({ tid: first })
      }
    }
  }, [bilibiliOptions, onChange, option.tid, platform])

  useEffect(() => {
    if (platform === 'youtube' && !asString(option.categoryId) && youtubeOptions.length > 0) {
      onChange({ categoryId: youtubeOptions[0].value })
    }
  }, [onChange, option.categoryId, platform, youtubeOptions])

  useEffect(() => {
    if (platform === 'pinterest' && !asString(option.boardId) && pinterestOptions.length > 0) {
      onChange({ boardId: pinterestOptions[0].value })
    }
  }, [onChange, option.boardId, pinterestOptions, platform])

  switch (platform) {
    case 'bilibili':
      return (
        <>
          <SelectField
            label="B 站分区"
            value={asString(option.tid)}
            placeholder={bilibiliState?.loading ? '加载分区中' : '选择分区'}
            options={bilibiliOptions}
            loading={bilibiliState?.loading}
            error={bilibiliState?.error}
            onChange={tid => onChange({ tid })}
          />
          <SelectField
            label="版权类型"
            value={asString(option.copyright, '1')}
            options={[
              { value: '1', label: '原创' },
              { value: '2', label: '转载' },
            ]}
            onChange={copyright => onChange({ copyright, source: copyright === '1' ? '' : option.source })}
          />
          {asString(option.copyright, '1') === '2' ? (
            <OptionField label="转载来源">
              <Input className={inputClassName} value={asString(option.source)} onChange={event => onChange({ source: event.target.value })} />
            </OptionField>
          ) : null}
        </>
      )
    case 'youtube':
      return (
        <>
          <SelectField
            label="视频分类"
            value={asString(option.categoryId)}
            placeholder={youtubeState?.loading ? '加载分类中' : '选择分类'}
            options={youtubeOptions}
            loading={youtubeState?.loading}
            error={youtubeState?.error}
            onChange={categoryId => onChange({ categoryId })}
          />
          <div className="grid gap-3 sm:grid-cols-2">
            <SelectField
              label="隐私状态"
              value={asString(option.privacyStatus, 'public')}
              options={[
                { value: 'public', label: '公开' },
                { value: 'unlisted', label: '不公开列出' },
                { value: 'private', label: '私密' },
              ]}
              onChange={privacyStatus => onChange({ privacyStatus })}
            />
            <SelectField
              label="授权协议"
              value={asString(option.license, 'youtube')}
              options={[
                { value: 'youtube', label: '标准 YouTube 协议' },
                { value: 'creativeCommon', label: 'Creative Commons' },
              ]}
              onChange={license => onChange({ license })}
            />
          </div>
          <ToggleGrid>
            <BooleanField label="通知订阅者" checked={asBoolean(option.notifySubscribers, true)} onChange={notifySubscribers => onChange({ notifySubscribers })} />
            <BooleanField label="允许嵌入" checked={asBoolean(option.embeddable, true)} onChange={embeddable => onChange({ embeddable })} />
            <BooleanField label="儿童内容" checked={asBoolean(option.selfDeclaredMadeForKids)} onChange={selfDeclaredMadeForKids => onChange({ selfDeclaredMadeForKids })} />
          </ToggleGrid>
        </>
      )
    case 'facebook':
      return (
        <ContentCategoryField
          value={asString(option.content_category, contentDraft.mediaType === 'video' ? 'reel' : 'post')}
          videoLocked={contentDraft.mediaType === 'video'}
          onChange={content_category => onChange({ content_category })}
        />
      )
    case 'instagram':
      return (
        <>
          <ContentCategoryField
            value={asString(option.content_category, contentDraft.mediaType === 'video' ? 'reel' : 'post')}
            videoLocked={contentDraft.mediaType === 'video'}
            onChange={content_category => onChange({ content_category })}
          />
          <div className="grid gap-3 sm:grid-cols-2">
            <SelectField
              label="媒体类型"
              value={asString(option.media_type)}
              placeholder="自动推断"
              options={[
                { value: 'IMAGE', label: 'IMAGE' },
                { value: 'VIDEO', label: 'VIDEO' },
                { value: 'CAROUSEL', label: 'CAROUSEL' },
                { value: 'REELS', label: 'REELS' },
              ]}
              onChange={media_type => onChange({ media_type })}
            />
            <OptionField label="位置 ID">
              <Input className={inputClassName} value={asString(option.location_id)} onChange={event => onChange({ location_id: event.target.value })} />
            </OptionField>
          </div>
          <OptionField label="替代文本">
            <Textarea className="min-h-20" value={asString(option.alt_text)} onChange={event => onChange({ alt_text: event.target.value })} />
          </OptionField>
        </>
      )
    case 'pinterest':
      return (
        <>
          <SelectField
            label="Board"
            value={asString(option.boardId)}
            placeholder={pinterestState?.loading ? '加载 Board 中' : '选择 Board'}
            options={pinterestOptions}
            loading={pinterestState?.loading}
            error={pinterestState?.error}
            onChange={boardId => onChange({ boardId })}
          />
          <div className="grid gap-3 sm:grid-cols-2">
            <OptionField label="封面 URL">
              <Input className={inputClassName} value={asString(option.coverImageUrl)} onChange={event => onChange({ coverImageUrl: event.target.value })} />
            </OptionField>
            <OptionField label="跳转链接">
              <Input className={inputClassName} value={asString(option.link)} onChange={event => onChange({ link: event.target.value })} />
            </OptionField>
          </div>
          <OptionField label="替代文本">
            <Input className={inputClassName} value={asString(option.altText)} onChange={event => onChange({ altText: event.target.value })} />
          </OptionField>
        </>
      )
    case 'tiktok':
      return (
        <>
          <SelectField
            label="隐私级别"
            value={asString(option.privacy_level, 'PUBLIC_TO_EVERYONE')}
            options={[
              { value: 'PUBLIC_TO_EVERYONE', label: '公开' },
              { value: 'MUTUAL_FOLLOW_FRIENDS', label: '好友可见' },
              { value: 'SELF_ONLY', label: '仅自己可见' },
            ]}
            onChange={privacy_level => onChange({ privacy_level })}
          />
          <ToggleGrid>
            <BooleanField label="允许评论" checked={!asBoolean(option.comment_disabled)} onChange={checked => onChange({ comment_disabled: !checked })} />
            <BooleanField label="允许合拍" checked={!asBoolean(option.duet_disabled)} onChange={checked => onChange({ duet_disabled: !checked })} />
            <BooleanField label="允许拼接" checked={!asBoolean(option.stitch_disabled)} onChange={checked => onChange({ stitch_disabled: !checked })} />
          </ToggleGrid>
          <ToggleGrid>
            <BooleanField label="商业内容披露" checked={asBoolean(option.brand_disclosure_enabled)} onChange={brand_disclosure_enabled => onChange({ brand_disclosure_enabled })} />
            <BooleanField label="我的品牌" checked={asBoolean(option.brand_organic_toggle)} onChange={brand_organic_toggle => onChange({ brand_organic_toggle })} />
            <BooleanField label="品牌合作内容" checked={asBoolean(option.brand_content_toggle)} onChange={brand_content_toggle => onChange({ brand_content_toggle })} />
          </ToggleGrid>
        </>
      )
    case 'twitter':
      return (
        <>
          <div className="grid gap-3 sm:grid-cols-2">
            <SelectField
              label="回复权限"
              value={asString(option.replySettings)}
              placeholder="所有人"
              options={[
                { value: 'following', label: '我关注的人' },
                { value: 'mentionedUsers', label: '提及的人' },
                { value: 'subscribers', label: '订阅者' },
                { value: 'verified', label: '认证用户' },
              ]}
              onChange={replySettings => onChange({ replySettings })}
            />
            <BooleanField label="包含 AI 生成媒体" checked={asBoolean(option.madeWithAi)} onChange={madeWithAi => onChange({ madeWithAi })} />
          </div>
          <OptionField label="媒体替代文本">
            <Textarea className="min-h-20" maxLength={1000} value={asString(option.altText)} onChange={event => onChange({ altText: event.target.value })} />
          </OptionField>
          <TwitterPollFields option={option} hasMedia={Boolean(contentDraft.mediaUrl.trim())} onChange={onChange} />
        </>
      )
    case 'threads':
      return (
        <>
          <div className="grid gap-3 sm:grid-cols-2">
            <OptionField label="位置 ID">
              <Input className={inputClassName} value={asString(option.location_id)} onChange={event => onChange({ location_id: event.target.value })} />
            </OptionField>
            <SelectField
              label="回复控制"
              value={asString(option.reply_control)}
              placeholder="默认"
              options={[
                { value: 'everyone', label: '所有人' },
                { value: 'accounts_you_follow', label: '我关注的人' },
                { value: 'mentioned_only', label: '仅提及的人' },
              ]}
              onChange={reply_control => onChange({ reply_control })}
            />
          </div>
          <div className="grid gap-3 sm:grid-cols-2">
            <OptionField label="话题标签">
              <Input className={inputClassName} value={asString(option.topic_tag)} onChange={event => onChange({ topic_tag: event.target.value })} />
            </OptionField>
            <OptionField label="链接附件">
              <Input className={inputClassName} value={asString(option.link_attachment_url)} onChange={event => onChange({ link_attachment_url: event.target.value })} />
            </OptionField>
          </div>
          <OptionField label="替代文本">
            <Textarea className="min-h-20" value={asString(option.alt_text)} onChange={event => onChange({ alt_text: event.target.value })} />
          </OptionField>
        </>
      )
    case 'xhs':
      return (
        <SelectField
          label="用户声明"
          value={asString(option.userDeclarationOrigin)}
          placeholder="不声明"
          options={[
            { value: '1', label: '虚拟演绎，仅供娱乐' },
            { value: '2', label: '笔记含 AI 合成内容' },
            { value: '3', label: '内容包含营销广告' },
          ]}
          onChange={userDeclarationOrigin => onChange({ userDeclarationOrigin })}
        />
      )
    case 'wxSph':
      return (
        <>
          <ToggleGrid>
            <BooleanField label="声明原创" checked={asBoolean(option.isOriginal)} onChange={isOriginal => onChange({ isOriginal })} />
          </ToggleGrid>
          <div className="grid gap-3 sm:grid-cols-3">
            <OptionField label="POI ID">
              <Input className={inputClassName} value={asString(option.poiId)} onChange={event => onChange({ poiId: event.target.value })} />
            </OptionField>
            <OptionField label="位置名称">
              <Input className={inputClassName} value={asString(option.poiName)} onChange={event => onChange({ poiName: event.target.value })} />
            </OptionField>
            <OptionField label="位置地址">
              <Input className={inputClassName} value={asString(option.poiAddress)} onChange={event => onChange({ poiAddress: event.target.value })} />
            </OptionField>
          </div>
          <div className="grid gap-3 sm:grid-cols-2">
            <OptionField label="活动 ID">
              <Input className={inputClassName} value={asString(option.eventTopicId)} onChange={event => onChange({ eventTopicId: event.target.value })} />
            </OptionField>
            <OptionField label="活动名称">
              <Input className={inputClassName} value={asString(option.eventName)} onChange={event => onChange({ eventName: event.target.value })} />
            </OptionField>
          </div>
        </>
      )
    case 'wxGzh':
      return (
        <>
          <div className="grid gap-3 sm:grid-cols-2">
            <OptionField label="作者">
              <Input className={inputClassName} value={asString(option.author)} onChange={event => onChange({ author: event.target.value })} />
            </OptionField>
            <OptionField label="原文链接">
              <Input className={inputClassName} value={asString(option.sourceUrl)} onChange={event => onChange({ sourceUrl: event.target.value })} />
            </OptionField>
          </div>
          <OptionField label="摘要">
            <Textarea className="min-h-20" value={asString(option.digest)} onChange={event => onChange({ digest: event.target.value })} />
          </OptionField>
          <ToggleGrid>
            <BooleanField label="开启评论" checked={asBoolean(option.open_comment)} onChange={open_comment => onChange({ open_comment })} />
            <BooleanField label="仅粉丝评论" checked={asBoolean(option.only_fans_can_comment)} onChange={only_fans_can_comment => onChange({ only_fans_can_comment })} />
            <BooleanField label="显示封面" checked={asBoolean(option.showCoverPic)} onChange={showCoverPic => onChange({ showCoverPic })} />
          </ToggleGrid>
        </>
      )
    case 'douyin':
      return (
        <>
          <div className="grid gap-3 sm:grid-cols-2">
            <OptionField label="Share ID">
              <Input className={inputClassName} value={asString(option.shareId)} onChange={event => onChange({ shareId: event.target.value })} />
            </OptionField>
            <OptionField label="短标题">
              <Input className={inputClassName} value={asString(option.short_title)} onChange={event => onChange({ short_title: event.target.value })} />
            </OptionField>
          </div>
          <OptionField label="话题标签" detail="逗号分隔">
            <Input className={inputClassName} value={asCsvString(option.hashtag_list)} onChange={event => onChange({ hashtag_list: event.target.value })} />
          </OptionField>
          <div className="grid gap-3 sm:grid-cols-3">
            <SelectField
              label="下载权限"
              value={asString(option.download_type)}
              placeholder="默认"
              options={[
                { value: '1', label: '允许下载' },
                { value: '2', label: '不允许下载' },
              ]}
              onChange={download_type => onChange({ download_type })}
            />
            <SelectField
              label="私密状态"
              value={asString(option.private_status)}
              placeholder="默认"
              options={[
                { value: '0', label: '公开' },
                { value: '1', label: '私密' },
              ]}
              onChange={private_status => onChange({ private_status })}
            />
            <OptionField label="封面时间(ms)">
              <Input className={inputClassName} type="number" value={asString(option.cover_tsp)} onChange={event => onChange({ cover_tsp: event.target.value })} />
            </OptionField>
          </div>
          <OptionField label="自定义封面 URL">
            <Input className={inputClassName} value={asString(option.custom_cover_image_url)} onChange={event => onChange({ custom_cover_image_url: event.target.value })} />
          </OptionField>
        </>
      )
    case 'KWAI':
      return (
        <>
          <div className="grid gap-3 sm:grid-cols-2">
            <OptionField label="封面 URL">
              <Input className={inputClassName} value={asString(option.cover)} onChange={event => onChange({ cover: event.target.value })} />
            </OptionField>
            <OptionField label="话题">
              <Input className={inputClassName} value={asString(option.photo_topic)} onChange={event => onChange({ photo_topic: event.target.value })} />
            </OptionField>
          </div>
          <div className="grid gap-3 sm:grid-cols-2">
            <OptionField label="视频类型">
              <Input className={inputClassName} value={asString(option.stereo_type)} onChange={event => onChange({ stereo_type: event.target.value })} />
            </OptionField>
            <OptionField label="挂载商品 ID">
              <Input className={inputClassName} value={asString(option.merchant_product_id)} onChange={event => onChange({ merchant_product_id: event.target.value })} />
            </OptionField>
          </div>
        </>
      )
    case 'linkedin':
      return (
        <>
          <div className="grid gap-3 sm:grid-cols-2">
            <SelectField
              label="可见性"
              value={asString(option.visibility, 'PUBLIC')}
              options={[
                { value: 'PUBLIC', label: '公开' },
                { value: 'CONNECTIONS', label: '仅联系人' },
              ]}
              onChange={visibility => onChange({ visibility })}
            />
            <SelectField
              label="分发渠道"
              value={asString(option.distribution, 'MAIN_FEED')}
              options={[
                { value: 'MAIN_FEED', label: '主页 Feed' },
                { value: 'NONE', label: '不分发' },
              ]}
              onChange={distribution => onChange({ distribution })}
            />
          </div>
          <div className="grid gap-3 sm:grid-cols-2">
            <OptionField label="Author URN">
              <Input className={inputClassName} value={asString(option.authorUrn)} onChange={event => onChange({ authorUrn: event.target.value })} />
            </OptionField>
            <OptionField label="账号类型">
              <Input className={inputClassName} value={asString(option.accountType)} onChange={event => onChange({ accountType: event.target.value })} />
            </OptionField>
          </div>
          <OptionField label="覆盖正文">
            <Textarea className="min-h-20" value={asString(option.commentary)} onChange={event => onChange({ commentary: event.target.value })} />
          </OptionField>
        </>
      )
    case 'google_business':
      return (
        <div className="flex items-center gap-2 rounded-md border border-dashed border-border bg-muted/25 p-3 text-sm text-muted-foreground">
          <GearSix className="size-4" weight="duotone" />
          Google Business 当前没有额外发布参数，沿用通用内容。
        </div>
      )
    default:
      return null
  }
}

function TwitterPollFields({
  option,
  hasMedia,
  onChange,
}: {
  option: PlatformOptionDraft
  hasMedia: boolean
  onChange: (patch: PlatformOptionDraft) => void
}) {
  const pollEnabled = asBoolean(option.pollEnabled)
  const pollOptions = asCsvString(option.pollOptions)

  return (
    <div className="grid gap-3 rounded-md border border-border bg-muted/25 p-3">
      <BooleanField label="启用投票" checked={pollEnabled} onChange={pollEnabled => onChange({ pollEnabled })} />
      {pollEnabled ? (
        <>
          {hasMedia ? (
            <InlineWarning message="X / Twitter 投票不能和媒体一起发布。当前 demo 要求媒体 URL，启用投票后将无法提交。" />
          ) : null}
          <OptionField label="投票选项" detail="逗号分隔，2 到 4 个，每个不超过 25 字">
            <Input className={inputClassName} value={pollOptions} onChange={event => onChange({ pollOptions: event.target.value })} />
          </OptionField>
          <OptionField label="持续时间(分钟)" detail="5 到 10080">
            <Input
              className={inputClassName}
              type="number"
              min={5}
              max={10080}
              value={asString(option.pollDurationMinutes, '1440')}
              onChange={event => onChange({ pollDurationMinutes: event.target.value })}
            />
          </OptionField>
        </>
      ) : null}
    </div>
  )
}

function ContentCategoryField({
  value,
  videoLocked,
  onChange,
}: {
  value: string
  videoLocked: boolean
  onChange: (value: string) => void
}) {
  return (
    <SelectField
      label="内容类型"
      detail={videoLocked ? '视频内容按开放平台规则固定为 Reel' : undefined}
      value={videoLocked ? 'reel' : value}
      disabled={videoLocked}
      options={[
        { value: 'post', label: 'Post' },
        { value: 'reel', label: 'Reel' },
        { value: 'story', label: 'Story' },
      ]}
      onChange={onChange}
    />
  )
}

function SelectField({
  label,
  detail,
  value,
  placeholder,
  options,
  loading,
  disabled,
  error,
  onChange,
}: {
  label: string
  detail?: string
  value: string
  placeholder?: string
  options: OptionItem[]
  loading?: boolean
  disabled?: boolean
  error?: string
  onChange: (value: string) => void
}) {
  return (
    <OptionField label={label} detail={detail}>
      <select
        className={selectClassName}
        value={value}
        disabled={disabled || loading}
        onChange={event => onChange(event.target.value)}
      >
        <option value="">{placeholder || '请选择'}</option>
        {options.map(option => (
          <option key={`${option.value}-${option.label}`} value={option.value} disabled={option.disabled}>
            {`${'　'.repeat(option.depth || 0)}${option.label}`}
          </option>
        ))}
      </select>
      {error ? <InlineWarning message={error} /> : null}
    </OptionField>
  )
}

function OptionField({ label, detail, children }: OptionFieldProps) {
  return (
    <Label className="grid gap-1.5">
      <span className="flex flex-wrap items-center gap-2 text-xs font-semibold text-muted-foreground">
        {label}
        {detail ? <span className="font-normal text-muted-foreground/85">{detail}</span> : null}
      </span>
      {children}
    </Label>
  )
}

function ToggleGrid({ children }: { children: ReactNode }) {
  return (
    <div className="grid gap-2 rounded-md border border-border bg-muted/20 p-2 sm:grid-cols-3">
      {children}
    </div>
  )
}

function BooleanField({
  label,
  checked,
  onChange,
}: {
  label: string
  checked: boolean
  onChange: (checked: boolean) => void
}) {
  const id = useId()

  return (
    <label htmlFor={id} className="flex min-h-9 items-center gap-2 rounded-md border border-border bg-card px-2.5 py-2 text-sm text-foreground">
      <input
        id={id}
        type="checkbox"
        className={checkboxClassName}
        checked={checked}
        onChange={event => onChange(event.target.checked)}
      />
      <span className="min-w-0 truncate">{label}</span>
      {checked ? <Check className="ml-auto size-3.5 shrink-0 text-primary" weight="bold" /> : null}
    </label>
  )
}

function InlineWarning({ message }: { message: string }) {
  return (
    <p className="mt-1.5 flex items-start gap-1.5 rounded-md border border-destructive/25 bg-destructive/10 px-2.5 py-1.5 text-xs text-destructive">
      <WarningCircle className="mt-0.5 size-3.5 shrink-0" weight="bold" />
      <span>{message}</span>
    </p>
  )
}

function PlatformLogo({ meta }: { meta: PlatformUiMeta }) {
  const [failed, setFailed] = useState(false)

  return (
    <span className="grid size-9 shrink-0 place-items-center rounded-md border border-border bg-card text-[10px] font-bold text-muted-foreground">
      {!failed && meta.logo ? (
        <img
          className="size-5 object-contain"
          src={meta.logo}
          alt=""
          onError={() => setFailed(true)}
        />
      ) : (
        meta.mark
      )}
    </span>
  )
}

function PlatformTabMark({ meta }: { meta: PlatformUiMeta }) {
  const [failed, setFailed] = useState(false)

  return (
    <span className="grid size-6 shrink-0 place-items-center rounded-sm border border-border bg-card text-[9px] font-bold text-primary">
      {!failed && meta.logo ? (
        <img
          className="size-4 object-contain"
          src={meta.logo}
          alt=""
          onError={() => setFailed(true)}
        />
      ) : (
        meta.mark.slice(0, 3)
      )}
    </span>
  )
}

function mapOptionItems(items: PublishOptionValueItem[]) {
  return items.map(item => ({
    value: String(item.value),
    label: item.label,
    disabled: item.disabled,
  }))
}

function flattenOptionItems(items: PublishOptionValueItem[], depth = 0): OptionItem[] {
  return items.flatMap((item) => {
    const current = {
      value: String(item.value),
      label: item.label,
      disabled: item.disabled,
      depth,
    }

    return [current, ...flattenOptionItems(item.children || [], depth + 1)]
  })
}

function asString(value: unknown, fallback = '') {
  if (value === undefined || value === null) {
    return fallback
  }

  return String(value)
}

function asBoolean(value: unknown, fallback = false) {
  return typeof value === 'boolean' ? value : fallback
}

function asCsvString(value: unknown) {
  if (Array.isArray(value)) {
    return value.map(item => String(item).trim()).filter(Boolean).join(', ')
  }

  return typeof value === 'string' ? value : ''
}
