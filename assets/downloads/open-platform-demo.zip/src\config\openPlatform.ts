import type { Platform } from '../types'

export type PlatformRegion = 'domestic' | 'overseas'
export type OpenPlatformEnvironmentId = 'cn' | 'global'

export interface OpenPlatformEnvironment {
  id: OpenPlatformEnvironmentId
  label: string
  shortLabel: string
  target: string
  apiBase: string
  apiKeyStorageKey: string
  region: PlatformRegion
  regionLabel: string
  supportText: string
}

export const DEFAULT_ENVIRONMENT_ID: OpenPlatformEnvironmentId = 'cn'

export const OPEN_PLATFORM_ENVIRONMENTS: Record<OpenPlatformEnvironmentId, OpenPlatformEnvironment> = {
  cn: {
    id: 'cn',
    label: '国内站',
    shortLabel: 'CN',
    target: 'https://aitoearn.cn',
    apiBase: '/cn-api',
    apiKeyStorageKey: 'aitoearn-open-platform-demo:api-key:cn:v1',
    region: 'domestic',
    regionLabel: '国内平台',
    supportText: '仅支持国内平台授权和分发',
  },
  global: {
    id: 'global',
    label: '海外站',
    shortLabel: 'AI',
    target: 'https://aitoearn.ai',
    apiBase: '/global-api',
    apiKeyStorageKey: 'aitoearn-open-platform-demo:api-key:global:v1',
    region: 'overseas',
    regionLabel: '海外平台',
    supportText: '仅支持海外平台授权和分发',
  },
}

export const OPEN_PLATFORM_ENVIRONMENT_LIST = [
  OPEN_PLATFORM_ENVIRONMENTS.cn,
  OPEN_PLATFORM_ENVIRONMENTS.global,
]

const domesticPlatforms = new Set<Platform>([
  'douyin',
  'xhs',
  'wxSph',
  'KWAI',
  'wxGzh',
  'bilibili',
])

export function isOpenPlatformEnvironmentId(value: string | null): value is OpenPlatformEnvironmentId {
  return value === 'cn' || value === 'global'
}

export function getPlatformRegion(platform: Platform): PlatformRegion {
  return domesticPlatforms.has(platform) ? 'domestic' : 'overseas'
}

export function getRegionLabel(region: PlatformRegion) {
  return region === 'domestic' ? '国内平台' : '海外平台'
}

export function getEnvironmentByRegion(region: PlatformRegion) {
  return region === 'domestic' ? OPEN_PLATFORM_ENVIRONMENTS.cn : OPEN_PLATFORM_ENVIRONMENTS.global
}
