export type Platform =
  | 'douyin'
  | 'xhs'
  | 'wxSph'
  | 'KWAI'
  | 'youtube'
  | 'wxGzh'
  | 'bilibili'
  | 'twitter'
  | 'tiktok'
  | 'facebook'
  | 'instagram'
  | 'threads'
  | 'pinterest'
  | 'linkedin'
  | 'google_business'

export type PlatformStatus = 'hidden' | 'available' | 'unavailable' | 'coming_soon'

export type PlatformAuthType = 'oauth2' | 'browser' | 'plugin' | 'qrcode' | string

export interface PlatformLocalizedText {
  'en-US'?: string
  'zh-CN'?: string
  [locale: string]: string | undefined
}

export interface PlatformMetadata {
  platform: Platform | string
  displayName?: PlatformLocalizedText
  logoUrl?: string
  authType?: PlatformAuthType
  authInstructions?: PlatformLocalizedText
  status?: PlatformStatus | string
  capabilities?: {
    auth?: Record<string, unknown>
    publish?: Record<string, unknown>
    [key: string]: Record<string, unknown> | undefined
  }
  contentLimits?: {
    maxTitleLength?: number | string | null
    [key: string]: unknown
  }
}

export interface ApiResponse<T> {
  code: number | string
  data: T
  message: string
  requestId?: string
  url?: string
  timestamp?: number
}

export type ApiIssuePathItem = string | number

export interface ApiValidationIssue {
  code?: string
  path?: ApiIssuePathItem[]
  params?: Record<string, unknown>
  message?: string
}

export interface PublishValidationErrorData {
  platform?: Platform | string
  accountId?: string
  issues?: ApiValidationIssue[]
}

export interface ChannelAccount {
  id: string
  userId?: string
  type: Platform | string
  uid: string
  account?: string
  avatar?: string
  nickname: string
  fansCount?: number
  workCount?: number
  status: number
  groupId?: string
  createdAt?: string
  updatedAt?: string
}

export interface ChannelAccountList {
  total: number
  list: ChannelAccount[]
}

export type AuthSessionStatus = 'pending' | 'completed' | 'failed'

export interface ChannelAccountAuthStart {
  url: string
  sessionId: string
  expiresAt?: string
}

export interface ChannelAuthConnectedAccount {
  accountId: string
  platform: Platform
  platformUid: string
  displayName: string
  avatarUrl?: string
}

export interface ChannelAccountAuthStatus {
  sessionId: string
  status: AuthSessionStatus
  requiresSelection: boolean
  expiresAt?: string
  accountId?: string
  accountIds?: string[]
  accounts?: ChannelAuthConnectedAccount[]
}

export interface PublishOptionValueItem {
  value: string
  label: string
  description?: string
  disabled?: boolean
  children?: PublishOptionValueItem[]
  extra?: Record<string, unknown>
}

export interface PublishOptionValues {
  field: string
  valueType: 'list' | 'tree'
  items: PublishOptionValueItem[]
}

export interface UploadSignData {
  id: string
  path: string
  url: string
  uploadUrl?: string
  uploadFields?: Record<string, string>
}

export interface AssetVo {
  id: string
  path: string
  url?: string
  type: string
  status: string
  size?: number
  mimeType?: string
  filename?: string
}

export interface PublishMediaInput {
  url: string
  metadata?: {
    type: 'video' | 'image'
  }
}

export interface PublishContentInput {
  title?: string
  body?: string
  media: PublishMediaInput[]
  cover?: PublishMediaInput
}

export interface ChannelCreatePublishFlowItem {
  accountId: string
  platform: Platform
  option?: Record<string, unknown>
  overrides?: PublishContentInput
}

export interface ChannelCreatePublishFlowParams {
  flowId?: string
  content: PublishContentInput
  publishAt: string
  context?: {
    type?: 'video' | 'image_text'
    source?: 'web' | string
    videoUrl?: string
    imgUrlList?: string[]
  }
  items: ChannelCreatePublishFlowItem[]
}

export interface ChannelPublishFlowTask {
  id: string
  accountId: string
  platform: Platform
  status?: number
  publishTime?: string
  platformWorkId?: string
  workLink?: string
  errorMsg?: string
}

export interface ChannelPublishFlow {
  flowId: string
  tasks: ChannelPublishFlowTask[]
}

export interface ChannelPublishRecord {
  id?: string
  recordId?: string
  accountId?: string
  platform?: Platform | string
  status?: number
  publishTime?: string
  publishedAt?: string
  platformWorkId?: string
  workLink?: string
  errorMsg?: string
}

export interface ChannelPublishUserAction {
  recordId: string
  platform: Platform | string
  shareId?: string
  schemeUrl?: string
  shortLink?: string
  expiresAt?: string | Date
}

export interface PlatformDraft {
  enabled: boolean
  accountId: string
}

export interface ContentDraft {
  title: string
  body: string
  topics: string
  mediaUrl: string
  mediaType: 'video' | 'image'
  coverUrl: string
  publishAt: string
}

export type PlatformOptionDraft = Record<string, unknown>

export type PlatformOptionsDraft = Partial<Record<Platform, PlatformOptionDraft>>

export interface UploadState {
  fileName: string
  progress: number
  status: 'idle' | 'signing' | 'uploading' | 'confirming' | 'done' | 'error'
  error?: string
}
