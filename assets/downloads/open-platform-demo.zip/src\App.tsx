import type {
  ChannelAccount,
  ChannelPublishFlow,
  ChannelPublishRecord,
  ChannelPublishUserAction,
  ContentDraft,
  Platform,
  PlatformOptionDraft,
  PlatformOptionsDraft,
  ApiResponse,
  PublishValidationErrorData,
  UploadState,
} from './types'
import {
  ArrowClockwise,
  Broadcast,
  Check,
  CheckCircle,
  CloudArrowUp,
  Copy,
  Eye,
  FilmSlate,
  GlobeHemisphereEast,
  Key,
  Link,
  PaperPlaneTilt,
  Play,
  PlugsConnected,
  QrCode,
  RocketLaunch,
  ShieldCheck,
  WarningCircle,
  X,
} from '@phosphor-icons/react'
import { motion, useReducedMotion } from 'motion/react'
import { useCallback, useEffect, useMemo, useRef, useState } from 'react'
import type { ReactNode } from 'react'
import {
  createPublishFlow,
  getAccounts,
  getAccountPublishOptionValues,
  getAuthStatus,
  getPlatforms,
  getPublishFlow,
  getPublishRecord,
  getPublishUserAction,
  OpenPlatformApiError,
  startAccountAuth,
  uploadPublishFile,
} from './api/openPlatform'
import { Badge } from './components/ui/badge'
import { Button } from './components/ui/button'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from './components/ui/card'
import { Input } from './components/ui/input'
import { Label } from './components/ui/label'
import {
  PlatformOptionsPanel,
  getPublishOptionValuesKey,
  type PublishOptionValuesState,
} from './components/PlatformOptionsPanel'
import { Separator } from './components/ui/separator'
import { Tabs, TabsContent, TabsList, TabsTrigger } from './components/ui/tabs'
import { Textarea } from './components/ui/textarea'
import {
  DEFAULT_ENVIRONMENT_ID,
  OPEN_PLATFORM_ENVIRONMENT_LIST,
  OPEN_PLATFORM_ENVIRONMENTS,
  getEnvironmentByRegion,
  isOpenPlatformEnvironmentId,
  type OpenPlatformEnvironment,
  type OpenPlatformEnvironmentId,
} from './config/openPlatform'
import {
  buildPublishPayload,
  canAuthorizePlatform,
  createFallbackPlatformInfos,
  createPlatformMetaMap,
  formatCompactTime,
  fromDateTimeLocalValue,
  getDefaultPublishAt,
  getPlatformSupportLabel,
  getPlatformUiMeta,
  getStatusText,
  inferMediaType,
  isDemoPublishSelectableAccount,
  isPluginPublishOnlyPlatform,
  isSupportedPlatform,
  isTerminalStatus,
  normalizePlatformMetadataList,
  supportedPlatforms,
  toDateTimeLocalValue,
  validateBeforePublish,
} from './utils/publish'
import type { PlatformUiMeta } from './utils/publish'

const ENVIRONMENT_STORAGE_KEY = 'aitoearn-open-platform-demo:environment:v1'
const AUTH_POLLING_INTERVAL = 2000
const AUTH_POLLING_MAX_COUNT = 150
const DEMO_TOPIC = 'aitoearn'
const DOUYIN_USER_ACTION_STATUS = 8
const DOUYIN_POLL_MAX_COUNT = 120

const EMPTY_UPLOAD_STATE: UploadState = {
  fileName: '',
  progress: 0,
  status: 'idle',
}

const initialContentDraft: ContentDraft = {
  title: '开放平台发布测试',
  body: '这是一条来自 AiToEarn 开放平台 demo 的分发测试。',
  topics: DEMO_TOPIC,
  mediaUrl: '',
  mediaType: 'video',
  coverUrl: '',
  publishAt: getDefaultPublishAt(),
}

type AuthUiState = {
  phase: 'idle' | 'starting' | 'pending' | 'completed' | 'failed'
  sessionId?: string
  url?: string
  message?: string
  expiresAt?: string
  isPolling?: boolean
  pollCount?: number
}

type PlatformFilter = 'ready' | 'connected' | 'plugin' | 'other' | 'all'
type PublishInspectorTab = 'route' | 'request' | 'status'

type DouyinUserActionState =
  | { status: 'loading', recordId: string }
  | { status: 'ready', recordId: string, shortLink: string, schemeUrl: string, expiresAt?: string }
  | { status: 'error', recordId: string, error: string }

function sleep(ms: number) {
  return new Promise(resolve => window.setTimeout(resolve, ms))
}

function getInitialEnvironmentId(): OpenPlatformEnvironmentId {
  if (typeof window === 'undefined') {
    return DEFAULT_ENVIRONMENT_ID
  }

  const stored = window.localStorage.getItem(ENVIRONMENT_STORAGE_KEY)
  return isOpenPlatformEnvironmentId(stored) ? stored : DEFAULT_ENVIRONMENT_ID
}

function getStoredApiKey(environmentId: OpenPlatformEnvironmentId) {
  if (typeof window === 'undefined') {
    return ''
  }

  return window.localStorage.getItem(OPEN_PLATFORM_ENVIRONMENTS[environmentId].apiKeyStorageKey) || ''
}

function getAuthRedirectUri(environment: OpenPlatformEnvironment) {
  return new URL(window.location.pathname || '/', environment.target).toString()
}

function createPlatformRecord<T>(createValue: (platform: Platform) => T): Record<Platform, T> {
  return Object.fromEntries(
    supportedPlatforms.map(platform => [platform, createValue(platform)]),
  ) as Record<Platform, T>
}

function createEmptyAuthState(): Record<Platform, AuthUiState> {
  return createPlatformRecord(() => ({ phase: 'idle' }))
}

function getUsableAccounts(accounts: ChannelAccount[]) {
  return accounts.filter(account => account.status === 1 && isSupportedPlatform(account.type))
}

function formatLargeNumber(value?: number) {
  if (typeof value !== 'number') {
    return '0'
  }

  return new Intl.NumberFormat('zh-CN', {
    notation: 'compact',
    maximumFractionDigits: 1,
  }).format(value)
}

function getRecordStatus(taskStatus?: number, record?: ChannelPublishRecord) {
  return record?.status ?? taskStatus
}

function isDouyinWaitingForUserAction(platform: Platform | string | undefined, status?: number) {
  return platform === 'douyin' && status === DOUYIN_USER_ACTION_STATUS
}

function isPublishTaskTerminal(platform: Platform | string | undefined, status?: number) {
  return isDouyinWaitingForUserAction(platform, status) ? false : isTerminalStatus(status)
}

function canUseDouyinAction(platform: Platform | string | undefined, status: number | undefined, action?: DouyinUserActionState) {
  if (platform !== 'douyin') {
    return false
  }

  if (status === -1 || status === 1 || status === 5 || status === 7 || status === 9) {
    return false
  }

  return status === DOUYIN_USER_ACTION_STATUS || Boolean(action)
}

function hasDouyinUserAction(action: ChannelPublishUserAction): action is ChannelPublishUserAction & { shortLink: string, schemeUrl: string } {
  return Boolean(action.shortLink && action.schemeUrl)
}

function App() {
  const reduceMotion = useReducedMotion()
  const initialEnvironmentId = useMemo(() => getInitialEnvironmentId(), [])
  const [environmentId, setEnvironmentId] = useState<OpenPlatformEnvironmentId>(initialEnvironmentId)
  const environment = OPEN_PLATFORM_ENVIRONMENTS[environmentId]
  const [apiKey, setApiKey] = useState(() => getStoredApiKey(initialEnvironmentId))
  const [apiKeyDraft, setApiKeyDraft] = useState(() => getStoredApiKey(initialEnvironmentId))
  const [accounts, setAccounts] = useState<ChannelAccount[]>([])
  const [selectedAccountIds, setSelectedAccountIds] = useState<Set<string>>(new Set())
  const [accountsLoading, setAccountsLoading] = useState(false)
  const [accountsError, setAccountsError] = useState('')
  const [platformInfos, setPlatformInfos] = useState<PlatformUiMeta[]>(
    () => createFallbackPlatformInfos(OPEN_PLATFORM_ENVIRONMENTS[initialEnvironmentId].region),
  )
  const [platformMetadataLoading, setPlatformMetadataLoading] = useState(false)
  const [platformMetadataError, setPlatformMetadataError] = useState('')
  const [authStates, setAuthStates] = useState<Record<Platform, AuthUiState>>(createEmptyAuthState)
  const [contentDraft, setContentDraft] = useState<ContentDraft>(initialContentDraft)
  const [platformOptions, setPlatformOptions] = useState<PlatformOptionsDraft>({})
  const [publishOptionValues, setPublishOptionValues] = useState<Record<string, PublishOptionValuesState>>({})
  const [mediaUpload, setMediaUpload] = useState<UploadState>(EMPTY_UPLOAD_STATE)
  const [coverUpload, setCoverUpload] = useState<UploadState>(EMPTY_UPLOAD_STATE)
  const [requestJson, setRequestJson] = useState('')
  const [flow, setFlow] = useState<ChannelPublishFlow | null>(null)
  const [records, setRecords] = useState<Record<string, ChannelPublishRecord>>({})
  const [publishError, setPublishError] = useState('')
  const [publishErrorDetail, setPublishErrorDetail] = useState<ApiResponse<PublishValidationErrorData> | null>(null)
  const [publishing, setPublishing] = useState(false)
  const [publishInspectorTab, setPublishInspectorTab] = useState<PublishInspectorTab>('route')
  const [douyinActions, setDouyinActions] = useState<Record<string, DouyinUserActionState>>({})
  const [activeDouyinActionTaskId, setActiveDouyinActionTaskId] = useState<string | null>(null)
  const authStatesRef = useRef<Record<Platform, AuthUiState>>(createEmptyAuthState())
  const authPollTokens = useRef<Record<Platform, number>>(createPlatformRecord(() => 0))
  const authPollCounts = useRef<Record<Platform, number>>(createPlatformRecord(() => 0))
  const authPollingTimers = useRef<Record<Platform, number | undefined>>(createPlatformRecord(() => undefined))
  const authPollInFlight = useRef<Record<Platform, boolean>>(createPlatformRecord(() => false))
  const douyinActionsRef = useRef<Record<string, DouyinUserActionState>>({})
  const activeDouyinActionTaskIdRef = useRef<string | null>(null)
  const platformMetadataRequestId = useRef(0)
  const mounted = useRef(true)

  const platformMetaMap = useMemo(() => createPlatformMetaMap(platformInfos), [platformInfos])
  const selectedAccounts = useMemo(
    () => accounts.filter(account => selectedAccountIds.has(account.id) && isDemoPublishSelectableAccount(account)),
    [accounts, selectedAccountIds],
  )
  const usableAccounts = useMemo(() => getUsableAccounts(accounts), [accounts])
  const connectedPlatformCount = useMemo(() => {
    return new Set(usableAccounts.map(account => account.type).filter(isSupportedPlatform)).size
  }, [usableAccounts])
  const previewPayload = useMemo(() => {
    if (selectedAccounts.length === 0 || !contentDraft.mediaUrl.trim()) {
      return null
    }

    return buildPublishPayload(contentDraft, selectedAccounts, platformOptions, platformMetaMap)
  }, [contentDraft, platformMetaMap, platformOptions, selectedAccounts])

  useEffect(() => {
    authStatesRef.current = authStates
  }, [authStates])

  useEffect(() => {
    douyinActionsRef.current = douyinActions
  }, [douyinActions])

  useEffect(() => {
    activeDouyinActionTaskIdRef.current = activeDouyinActionTaskId
  }, [activeDouyinActionTaskId])

  useEffect(() => {
    setContentDraft(prev => (prev.topics === DEMO_TOPIC ? prev : { ...prev, topics: DEMO_TOPIC }))
  }, [])

  const stopAuthPolling = useCallback((platform: Platform, invalidate = false) => {
    const timerId = authPollingTimers.current[platform]
    if (timerId !== undefined) {
      window.clearTimeout(timerId)
      authPollingTimers.current[platform] = undefined
    }

    authPollInFlight.current[platform] = false

    if (invalidate) {
      authPollTokens.current[platform] += 1
      authPollCounts.current[platform] = 0
    }
  }, [])

  useEffect(() => {
    mounted.current = true

    return () => {
      mounted.current = false
      supportedPlatforms.forEach((platform) => {
        stopAuthPolling(platform, true)
      })
    }
  }, [stopAuthPolling])

  const switchEnvironment = useCallback((nextEnvironmentId: OpenPlatformEnvironmentId) => {
    if (nextEnvironmentId === environmentId) {
      return
    }

    const nextEnvironment = OPEN_PLATFORM_ENVIRONMENTS[nextEnvironmentId]
    supportedPlatforms.forEach(platform => stopAuthPolling(platform, true))

    window.localStorage.setItem(ENVIRONMENT_STORAGE_KEY, nextEnvironmentId)
    const nextApiKey = getStoredApiKey(nextEnvironmentId)
    const emptyAuthState = createEmptyAuthState()

    setEnvironmentId(nextEnvironmentId)
    setApiKey(nextApiKey)
    setApiKeyDraft(nextApiKey)
    setAccounts([])
    setSelectedAccountIds(new Set())
    setAccountsError('')
    setPlatformInfos(createFallbackPlatformInfos(nextEnvironment.region))
    setPlatformMetadataError('')
    setAuthStates(emptyAuthState)
    authStatesRef.current = emptyAuthState
    setPlatformOptions({})
    setPublishOptionValues({})
    setFlow(null)
    setRecords({})
    setDouyinActions({})
    douyinActionsRef.current = {}
    activeDouyinActionTaskIdRef.current = null
    setActiveDouyinActionTaskId(null)
    setRequestJson('')
    setPublishError('')
    setPublishErrorDetail(null)
  }, [environmentId, stopAuthPolling])

  const saveApiKey = useCallback(() => {
    const nextApiKey = apiKeyDraft.trim()
    setApiKey(nextApiKey)
    window.localStorage.setItem(environment.apiKeyStorageKey, nextApiKey)
    setAccountsError('')
    setPublishOptionValues({})
  }, [apiKeyDraft, environment.apiKeyStorageKey])

  const loadPlatformMetadata = useCallback(async (fresh = false) => {
    const requestId = platformMetadataRequestId.current + 1
    platformMetadataRequestId.current = requestId
    setPlatformMetadataLoading(true)
    setPlatformMetadataError('')

    try {
      const data = await getPlatforms(environment.apiBase, apiKey.trim() || undefined, fresh)
      if (platformMetadataRequestId.current !== requestId) {
        return
      }
      setPlatformInfos(normalizePlatformMetadataList(data, environment.region))
    }
    catch (error) {
      if (platformMetadataRequestId.current !== requestId) {
        return
      }
      setPlatformInfos(createFallbackPlatformInfos(environment.region))
      setPlatformMetadataError(error instanceof Error ? error.message : '平台元数据加载失败')
    }
    finally {
      if (platformMetadataRequestId.current === requestId) {
        setPlatformMetadataLoading(false)
      }
    }
  }, [apiKey, environment.apiBase, environment.region])

  useEffect(() => {
    void loadPlatformMetadata()
  }, [loadPlatformMetadata])

  const refreshAccounts = useCallback(async () => {
    if (!apiKey.trim()) {
      setAccounts([])
      setSelectedAccountIds(new Set())
      setAccountsError(`请先保存${environment.label}的 X-Api-Key`)
      return
    }

    setAccountsLoading(true)
    setAccountsError('')

    try {
      const data = await getAccounts(environment.apiBase, apiKey)
      const nextAccounts = data.list.filter(account => isSupportedPlatform(account.type))
      setAccounts(nextAccounts)
      setSelectedAccountIds((prev) => {
        const validIds = new Set(nextAccounts.filter(isDemoPublishSelectableAccount).map(account => account.id))
        const retained = new Set([...prev].filter(accountId => validIds.has(accountId)))

        if (retained.size > 0) {
          return retained
        }

        return new Set(nextAccounts.filter(isDemoPublishSelectableAccount).map(account => account.id))
      })
    }
    catch (error) {
      setAccountsError(error instanceof Error ? error.message : '账号列表加载失败')
    }
    finally {
      setAccountsLoading(false)
    }
  }, [apiKey, environment.apiBase, environment.label])

  useEffect(() => {
    if (apiKey) {
      void refreshAccounts()
      return
    }

    setAccounts([])
    setSelectedAccountIds(new Set())
  }, [apiKey, refreshAccounts])

  const beginAuthPolling = useCallback((
    platform: Platform,
    sessionId: string,
    token: number,
    requestApiBase: string,
    requestApiKey: string,
  ) => {
    function scheduleNextPoll() {
      const timerId = authPollingTimers.current[platform]
      if (timerId !== undefined) {
        window.clearTimeout(timerId)
      }

      authPollingTimers.current[platform] = window.setTimeout(() => {
        void pollAuthStatus()
      }, AUTH_POLLING_INTERVAL)
    }

    async function pollAuthStatus() {
      if (!mounted.current || authPollTokens.current[platform] !== token) {
        return
      }

      const current = authStatesRef.current[platform]
      if (!current.isPolling || current.sessionId !== sessionId) {
        stopAuthPolling(platform)
        return
      }

      if (authPollInFlight.current[platform]) {
        scheduleNextPoll()
        return
      }

      const nextPollCount = authPollCounts.current[platform] + 1
      authPollCounts.current[platform] = nextPollCount

      if (nextPollCount > AUTH_POLLING_MAX_COUNT) {
        stopAuthPolling(platform)
        setAuthStates(prev => ({
          ...prev,
          [platform]: {
            ...prev[platform],
            phase: 'failed',
            isPolling: false,
            message: '授权轮询超时',
          },
        }))
        return
      }

      setAuthStates(prev => ({
        ...prev,
        [platform]: {
          ...prev[platform],
          phase: 'pending',
          isPolling: true,
          message: `正在轮询 ${nextPollCount}`,
          pollCount: nextPollCount,
        },
      }))

      authPollInFlight.current[platform] = true
      try {
        const status = await getAuthStatus(requestApiBase, requestApiKey, platform, sessionId)

        if (!mounted.current || authPollTokens.current[platform] !== token) {
          return
        }

        if (status.status === 'completed') {
          stopAuthPolling(platform)
          setAuthStates(prev => ({
            ...prev,
            [platform]: {
              ...prev[platform],
              phase: 'completed',
              isPolling: false,
              message: '授权完成',
              expiresAt: status.expiresAt,
            },
          }))
          await refreshAccounts()
          return
        }

        if (status.status === 'failed') {
          stopAuthPolling(platform)
          setAuthStates(prev => ({
            ...prev,
            [platform]: {
              ...prev[platform],
              phase: 'failed',
              isPolling: false,
              message: '授权失败',
              expiresAt: status.expiresAt,
            },
          }))
          return
        }

        setAuthStates(prev => ({
          ...prev,
          [platform]: {
            ...prev[platform],
            phase: 'pending',
            isPolling: true,
            message: '等待授权完成',
            expiresAt: status.expiresAt,
          },
        }))
        scheduleNextPoll()
      }
      catch (error) {
        if (!mounted.current || authPollTokens.current[platform] !== token) {
          return
        }

        stopAuthPolling(platform)
        setAuthStates(prev => ({
          ...prev,
          [platform]: {
            ...prev[platform],
            phase: 'failed',
            isPolling: false,
            message: error instanceof Error ? error.message : '授权状态查询失败',
          },
        }))
      }
      finally {
        authPollInFlight.current[platform] = false
      }
    }

    void pollAuthStatus()
  }, [refreshAccounts, stopAuthPolling])

  const startAuth = useCallback(async (platform: Platform) => {
    const requestApiKey = apiKey.trim()
    const meta = getPlatformUiMeta(platform, platformMetaMap)

    if (!requestApiKey) {
      setAccountsError(`请先保存${environment.label}的 X-Api-Key`)
      return
    }

    if (!canAuthorizePlatform(meta)) {
      setAccountsError(`${meta.label}: ${getPlatformSupportLabel(meta)}`)
      return
    }

    stopAuthPolling(platform, true)

    const startingState: AuthUiState = {
      phase: 'starting',
      isPolling: true,
      message: '正在创建授权会话',
    }
    authStatesRef.current = {
      ...authStatesRef.current,
      [platform]: startingState,
    }
    setAuthStates(prev => ({
      ...prev,
      [platform]: startingState,
    }))

    const authWindow = window.open('about:blank')

    try {
      const redirectUri = getAuthRedirectUri(environment)
      const data = await startAccountAuth(environment.apiBase, requestApiKey, platform, redirectUri)
      const token = authPollTokens.current[platform] + 1
      authPollTokens.current[platform] = token
      authPollCounts.current[platform] = 0
      const pendingState: AuthUiState = {
        phase: 'pending',
        sessionId: data.sessionId,
        url: data.url,
        expiresAt: data.expiresAt,
        isPolling: true,
        message: '授权窗口已打开，正在轮询',
        pollCount: 0,
      }
      authStatesRef.current = {
        ...authStatesRef.current,
        [platform]: pendingState,
      }
      setAuthStates(prev => ({
        ...prev,
        [platform]: pendingState,
      }))

      if (authWindow) {
        authWindow.location.href = data.url
      }
      else {
        window.open(data.url)
      }

      beginAuthPolling(platform, data.sessionId, token, environment.apiBase, requestApiKey)
    }
    catch (error) {
      authWindow?.close()
      stopAuthPolling(platform)
      setAuthStates(prev => ({
        ...prev,
        [platform]: {
          phase: 'failed',
          isPolling: false,
          message: error instanceof Error ? error.message : '授权会话创建失败',
        },
      }))
    }
  }, [apiKey, beginAuthPolling, environment, platformMetaMap, stopAuthPolling])

  const toggleAccount = useCallback((accountId: string) => {
    const account = accounts.find(item => item.id === accountId)
    if (!account || !isDemoPublishSelectableAccount(account)) {
      return
    }

    setSelectedAccountIds((prev) => {
      const next = new Set(prev)
      if (next.has(accountId)) {
        next.delete(accountId)
      }
      else {
        next.add(accountId)
      }
      return next
    })
  }, [accounts])

  const updateContentDraft = useCallback((patch: Partial<ContentDraft>) => {
    setContentDraft(prev => ({ ...prev, ...patch, topics: DEMO_TOPIC }))
  }, [])

  const updatePlatformOption = useCallback((platform: Platform, patch: PlatformOptionDraft) => {
    setPlatformOptions(prev => ({
      ...prev,
      [platform]: {
        ...(prev[platform] || {}),
        ...patch,
      },
    }))
  }, [])

  const loadAccountPublishOptionValues = useCallback((
    accountId: string,
    field: string,
    params?: Record<string, string>,
  ) => {
    if (!apiKey.trim()) {
      return
    }

    const key = getPublishOptionValuesKey(accountId, field, params)
    const current = publishOptionValues[key]
    if (current?.loading || current?.items.length > 0 || current?.error) {
      return
    }

    setPublishOptionValues(prev => ({
      ...prev,
      [key]: {
        items: prev[key]?.items || [],
        loading: true,
        error: '',
      },
    }))

    getAccountPublishOptionValues(environment.apiBase, apiKey, accountId, field, params)
      .then((data) => {
        setPublishOptionValues(prev => ({
          ...prev,
          [key]: {
            items: data.items || [],
            loading: false,
            error: '',
          },
        }))
      })
      .catch((error) => {
        setPublishOptionValues(prev => ({
          ...prev,
          [key]: {
            items: [],
            loading: false,
            error: error instanceof Error ? error.message : '动态参数加载失败',
          },
        }))
      })
  }, [apiKey, environment.apiBase, publishOptionValues])

  const uploadFile = useCallback(async (kind: 'media' | 'cover', file: File) => {
    const setUpload = kind === 'media' ? setMediaUpload : setCoverUpload

    if (!apiKey.trim()) {
      setUpload({
        fileName: file.name,
        progress: 0,
        status: 'error',
        error: `请先保存${environment.label}的 X-Api-Key`,
      })
      return
    }

    setUpload({
      fileName: file.name,
      progress: 0,
      status: 'signing',
    })

    try {
      const url = await uploadPublishFile(environment.apiBase, apiKey, file, (progress) => {
        setUpload(prev => ({
          ...prev,
          progress,
          status: progress >= 100 ? 'confirming' : 'uploading',
        }))
      })

      setUpload({
        fileName: file.name,
        progress: 100,
        status: 'done',
      })

      setContentDraft((prev) => {
        if (kind === 'cover') {
          return { ...prev, coverUrl: url }
        }

        return {
          ...prev,
          mediaUrl: url,
          mediaType: file.type.startsWith('image/') ? 'image' : 'video',
        }
      })
    }
    catch (error) {
      setUpload({
        fileName: file.name,
        progress: 0,
        status: 'error',
        error: error instanceof Error ? error.message : '上传失败',
      })
    }
  }, [apiKey, environment.apiBase, environment.label])

  const updateDouyinAction = useCallback((
    taskId: string,
    action: DouyinUserActionState,
  ) => {
    setDouyinActions((prev) => {
      const next = { ...prev, [taskId]: action }
      douyinActionsRef.current = next
      return next
    })
  }, [])

  const ensureDouyinUserAction = useCallback(async (taskId: string) => {
    const current = douyinActionsRef.current[taskId]
    if (current?.status === 'loading' || current?.status === 'ready') {
      return
    }

    updateDouyinAction(taskId, { status: 'loading', recordId: taskId })

    try {
      const action = await getPublishUserAction(environment.apiBase, apiKey, taskId)
      if (!hasDouyinUserAction(action)) {
        updateDouyinAction(taskId, {
          status: 'error',
          recordId: taskId,
          error: '抖音扫码入口暂未返回，请稍后刷新',
        })
        return
      }

      updateDouyinAction(taskId, {
        status: 'ready',
        recordId: action.recordId || taskId,
        shortLink: action.shortLink,
        schemeUrl: action.schemeUrl,
        expiresAt: action.expiresAt ? String(action.expiresAt) : undefined,
      })
    }
    catch (error) {
      updateDouyinAction(taskId, {
        status: 'error',
        recordId: taskId,
        error: error instanceof Error ? error.message : '抖音扫码入口获取失败',
      })
    }
  }, [apiKey, environment.apiBase, updateDouyinAction])

  const refreshRecordsOnce = useCallback(async (activeFlow: ChannelPublishFlow) => {
    const recordEntries = await Promise.all(
      activeFlow.tasks.map(async (task) => {
        try {
          const douyinAction = task.platform === 'douyin' ? douyinActionsRef.current[task.id] : undefined
          const recordId = douyinAction?.status === 'ready' ? douyinAction.recordId : task.id
          const record = await getPublishRecord(environment.apiBase, apiKey, recordId)
          return [task.id, record] as const
        }
        catch {
          return [task.id, null] as const
        }
      }),
    )
    const recordPatch = Object.fromEntries(
      recordEntries.filter((entry): entry is readonly [string, ChannelPublishRecord] => Boolean(entry[1])),
    )

    setRecords(prev => ({
      ...prev,
      ...recordPatch,
    }))

    activeFlow.tasks.forEach((task) => {
      const status = getRecordStatus(task.status, recordPatch[task.id])
      const action = douyinActionsRef.current[task.id]
      if (isDouyinWaitingForUserAction(task.platform, status) && action?.status !== 'ready' && action?.status !== 'loading') {
        void ensureDouyinUserAction(task.id)
      }
      if (task.platform === 'douyin' && status === 1 && activeDouyinActionTaskIdRef.current === task.id) {
        activeDouyinActionTaskIdRef.current = null
        setActiveDouyinActionTaskId(null)
      }
    })

    try {
      const latestFlow = await getPublishFlow(environment.apiBase, apiKey, activeFlow.flowId)
      setFlow(latestFlow)
      return { latestFlow, recordPatch }
    }
    catch {
      return { latestFlow: activeFlow, recordPatch }
    }
  }, [apiKey, ensureDouyinUserAction, environment.apiBase])

  const pollPublishRecords = useCallback(async (activeFlow: ChannelPublishFlow) => {
    let latestFlow = activeFlow
    let localRecords: Record<string, ChannelPublishRecord> = {}

    for (let index = 0; index < DOUYIN_POLL_MAX_COUNT; index += 1) {
      if (!mounted.current) {
        return
      }

      const result = await refreshRecordsOnce(latestFlow)
      latestFlow = result.latestFlow
      localRecords = { ...localRecords, ...result.recordPatch }
      const allTerminal = latestFlow.tasks.every((task) => {
        const record = localRecords[task.id]
        return isPublishTaskTerminal(task.platform, getRecordStatus(task.status, record))
      })

      if (allTerminal) {
        return
      }

      await sleep(5000)
    }
  }, [refreshRecordsOnce])

  const publish = useCallback(async () => {
    const validationMessage = validateBeforePublish(apiKey, contentDraft, selectedAccounts, platformOptions, platformMetaMap)
    if (validationMessage) {
      setPublishError(validationMessage)
      setPublishErrorDetail(null)
      return
    }

    const payload = buildPublishPayload(contentDraft, selectedAccounts, platformOptions, platformMetaMap)
    setRequestJson(JSON.stringify(payload, null, 2))
    setPublishError('')
    setPublishErrorDetail(null)
    setPublishing(true)
    setFlow(null)
    setRecords({})
    setDouyinActions({})
    douyinActionsRef.current = {}
    activeDouyinActionTaskIdRef.current = null
    setActiveDouyinActionTaskId(null)

    try {
      const createdFlow = await createPublishFlow(environment.apiBase, apiKey, payload)
      setFlow(createdFlow)
      setPublishInspectorTab('status')
      await pollPublishRecords(createdFlow)
    }
    catch (error) {
      if (error instanceof OpenPlatformApiError) {
        setPublishError(error.message)
        setPublishErrorDetail(error.payload as ApiResponse<PublishValidationErrorData>)
      }
      else {
        setPublishError(error instanceof Error ? error.message : '创建发布 Flow 失败')
        setPublishErrorDetail(null)
      }
    }
    finally {
      setPublishing(false)
    }
  }, [apiKey, contentDraft, environment.apiBase, platformMetaMap, platformOptions, pollPublishRecords, selectedAccounts])

  const copyRequestJson = useCallback(async () => {
    const value = requestJson || (previewPayload ? JSON.stringify(previewPayload, null, 2) : '')
    if (!value) {
      return
    }

    await navigator.clipboard.writeText(value)
  }, [previewPayload, requestJson])

  const manuallyRefreshRecords = useCallback(() => {
    if (flow) {
      void refreshRecordsOnce(flow)
    }
  }, [flow, refreshRecordsOnce])

  const openDouyinAction = useCallback((taskId: string) => {
    activeDouyinActionTaskIdRef.current = taskId
    setActiveDouyinActionTaskId(taskId)
    void ensureDouyinUserAction(taskId)
  }, [ensureDouyinUserAction])

  const closeDouyinAction = useCallback(() => {
    activeDouyinActionTaskIdRef.current = null
    setActiveDouyinActionTaskId(null)
  }, [])

  const activeDouyinAction = activeDouyinActionTaskId
    ? douyinActions[activeDouyinActionTaskId]
    : null

  return (
    <main className="min-h-[100dvh] overflow-x-hidden">
      <div className="page-backdrop" aria-hidden="true" />
      <motion.div
        className="mx-auto grid w-full max-w-[1680px] gap-4 px-4 py-5 sm:px-5 lg:px-6"
        initial={reduceMotion ? false : { opacity: 0, y: 14 }}
        animate={reduceMotion ? undefined : { opacity: 1, y: 0 }}
        transition={{ duration: 0.36, ease: [0.16, 1, 0.3, 1] }}
      >
        <Header
          environment={environment}
          apiKeyDraft={apiKeyDraft}
          apiKeySaved={Boolean(apiKey)}
          accountsLoading={accountsLoading}
          platformMetadataLoading={platformMetadataLoading}
          onEnvironmentChange={switchEnvironment}
          onApiKeyChange={setApiKeyDraft}
          onSaveApiKey={saveApiKey}
          onRefreshAccounts={refreshAccounts}
          onRefreshMetadata={() => void loadPlatformMetadata(true)}
        />

        <OverviewStrip
          environment={environment}
          accountCount={accounts.length}
          connectedPlatformCount={connectedPlatformCount}
          selectedCount={selectedAccounts.length}
          flow={flow}
        />

        <section className="grid items-start gap-4">
          <ConnectPanel
            environment={environment}
            accounts={accounts}
            platformInfos={platformInfos}
            platformMetaMap={platformMetaMap}
            platformMetadataLoading={platformMetadataLoading}
            platformMetadataError={platformMetadataError}
            selectedAccountIds={selectedAccountIds}
            accountsLoading={accountsLoading}
            accountsError={accountsError}
            authStates={authStates}
            onStartAuth={startAuth}
            onToggleAccount={toggleAccount}
            onRefreshAccounts={refreshAccounts}
          />

          <div className="grid items-start gap-4 xl:grid-cols-[minmax(0,1fr)_520px] 2xl:grid-cols-[minmax(0,1fr)_600px]">
            <ContentPanel
              contentDraft={contentDraft}
              mediaUpload={mediaUpload}
              coverUpload={coverUpload}
              onContentChange={updateContentDraft}
              onUploadFile={uploadFile}
            />
            <PublishInspector
              selectedAccounts={selectedAccounts}
              contentDraft={contentDraft}
              platformMetaMap={platformMetaMap}
              platformOptions={platformOptions}
              publishOptionValues={publishOptionValues}
              previewPayload={previewPayload}
              requestJson={requestJson}
              publishError={publishError}
              publishErrorDetail={publishErrorDetail}
              activeTab={publishInspectorTab}
              publishing={publishing}
              onPlatformOptionChange={updatePlatformOption}
              onLoadOptionValues={loadAccountPublishOptionValues}
              onCopyJson={copyRequestJson}
              onPublish={publish}
              onTabChange={setPublishInspectorTab}
              flow={flow}
              records={records}
              douyinActions={douyinActions}
              onOpenDouyinAction={openDouyinAction}
              onRefresh={manuallyRefreshRecords}
            />
          </div>
        </section>
      </motion.div>
      <DouyinQRCodeModal
        action={activeDouyinAction}
        onClose={closeDouyinAction}
      />
    </main>
  )
}

interface HeaderProps {
  environment: OpenPlatformEnvironment
  apiKeyDraft: string
  apiKeySaved: boolean
  accountsLoading: boolean
  platformMetadataLoading: boolean
  onEnvironmentChange: (environmentId: OpenPlatformEnvironmentId) => void
  onApiKeyChange: (value: string) => void
  onSaveApiKey: () => void
  onRefreshAccounts: () => void
  onRefreshMetadata: () => void
}

function Header({
  environment,
  apiKeyDraft,
  apiKeySaved,
  accountsLoading,
  platformMetadataLoading,
  onEnvironmentChange,
  onApiKeyChange,
  onSaveApiKey,
  onRefreshAccounts,
  onRefreshMetadata,
}: HeaderProps) {
  return (
    <Card className="overflow-hidden rounded-xl border-border/80 bg-card shadow-[0_18px_60px_oklch(0.35_0.045_286_/_0.10)]">
      <div className="h-1 bg-[image:var(--gradientBackColor)]" />
      <div className="grid gap-5 p-4 lg:grid-cols-[minmax(300px,0.8fr)_minmax(520px,1.2fr)] lg:items-center">
        <div className="flex min-w-0 items-center gap-3">
          <div className="grid size-12 shrink-0 place-items-center rounded-lg bg-[image:var(--gradientBackColor)] text-primary-foreground shadow-md">
            <RocketLaunch size={25} weight="duotone" />
          </div>
          <div className="min-w-0">
            <p className="text-sm font-semibold text-primary">AiToEarn Open Platform</p>
            <h1 className="text-2xl font-semibold leading-tight text-foreground sm:text-3xl">发布分发控制台</h1>
            <p className="mt-1 max-w-[48ch] text-sm text-muted-foreground">切换站点、授权账号、上传素材，然后创建发布 Flow。</p>
          </div>
        </div>

        <div className="grid gap-3">
          <div className="grid gap-3 md:grid-cols-[260px_minmax(260px,1fr)] xl:grid-cols-[260px_minmax(260px,1fr)_auto_auto]">
            <Tabs
              value={environment.id}
              onValueChange={(value) => {
                if (isOpenPlatformEnvironmentId(value)) {
                  onEnvironmentChange(value)
                }
              }}
            >
              <TabsList className="grid w-full grid-cols-2 bg-card/80">
                {OPEN_PLATFORM_ENVIRONMENT_LIST.map(item => (
                  <TabsTrigger key={item.id} value={item.id} className="gap-2">
                    <span className="rounded bg-muted px-1.5 py-0.5 text-[11px] font-semibold">{item.shortLabel}</span>
                    {item.label}
                  </TabsTrigger>
                ))}
              </TabsList>
            </Tabs>

            <Label className="gap-1">
              <span className="flex items-center gap-1.5 text-xs text-muted-foreground">
                <Key size={14} weight="bold" />
                {environment.label} X-Api-Key
              </span>
              <Input
                value={apiKeyDraft}
                onChange={event => onApiKeyChange(event.target.value)}
                placeholder="ak-..."
                type="password"
                autoComplete="off"
              />
            </Label>

            <Button type="button" className="self-end bg-[image:var(--gradientBackColor)]" onClick={onSaveApiKey}>
              <CheckCircle size={17} weight="bold" />
              保存 Key
            </Button>

            <Button
              type="button"
              variant="outline"
              className="self-end"
              onClick={onRefreshAccounts}
            >
              <ArrowClockwise className={accountsLoading ? 'animate-spin' : ''} size={17} weight="bold" />
              刷新账号
            </Button>
          </div>

          <div className="flex flex-wrap items-center gap-2 text-xs text-muted-foreground">
            <Badge variant={apiKeySaved ? 'success' : 'warning'}>
              <ShieldCheck size={13} weight="bold" />
              {apiKeySaved ? 'Key 已保存' : 'Key 未保存'}
            </Badge>
            <Badge variant="outline">
              <GlobeHemisphereEast size={13} weight="bold" />
              {environment.target}
            </Badge>
            <Badge variant="secondary">{environment.supportText}</Badge>
            <Button type="button" size="sm" variant="ghost" onClick={onRefreshMetadata}>
              <ArrowClockwise className={platformMetadataLoading ? 'animate-spin' : ''} size={15} weight="bold" />
              元数据
            </Button>
          </div>
        </div>
      </div>
    </Card>
  )
}

interface OverviewStripProps {
  environment: OpenPlatformEnvironment
  accountCount: number
  connectedPlatformCount: number
  selectedCount: number
  flow: ChannelPublishFlow | null
}

function OverviewStrip({
  environment,
  accountCount,
  connectedPlatformCount,
  selectedCount,
  flow,
}: OverviewStripProps) {
  return (
    <section className="grid gap-0 overflow-hidden rounded-xl border border-border bg-card shadow-sm md:grid-cols-4">
      <RibbonMetric label="当前站点" value={environment.label} detail={environment.regionLabel} />
      <RibbonMetric label="账号" value={`${accountCount}`} detail={`${connectedPlatformCount} 个平台已连接`} />
      <RibbonMetric label="目标" value={`${selectedCount}`} detail="已选发布账号" />
      <RibbonMetric label="Flow" value={flow ? `${flow.tasks.length}` : '0'} detail={flow ? flow.flowId : '等待创建'} />
    </section>
  )
}

function RibbonMetric({ label, value, detail }: { label: string, value: string, detail: string }) {
  return (
    <div className="grid gap-1 border-b border-border p-4 md:border-b-0 md:border-r md:last:border-r-0">
      <span className="text-xs font-medium text-muted-foreground">{label}</span>
      <strong className="truncate text-2xl font-semibold text-foreground">{value}</strong>
      <span className="truncate text-xs text-muted-foreground">{detail}</span>
    </div>
  )
}

interface ConnectPanelProps {
  environment: OpenPlatformEnvironment
  accounts: ChannelAccount[]
  platformInfos: PlatformUiMeta[]
  platformMetaMap: Map<Platform, PlatformUiMeta>
  platformMetadataLoading: boolean
  platformMetadataError: string
  selectedAccountIds: Set<string>
  accountsLoading: boolean
  accountsError: string
  authStates: Record<Platform, AuthUiState>
  onStartAuth: (platform: Platform) => void
  onToggleAccount: (accountId: string) => void
  onRefreshAccounts: () => void
}

function ConnectPanel({
  environment,
  accounts,
  platformInfos,
  platformMetaMap,
  platformMetadataLoading,
  platformMetadataError,
  selectedAccountIds,
  accountsLoading,
  accountsError,
  authStates,
  onStartAuth,
  onToggleAccount,
  onRefreshAccounts,
}: ConnectPanelProps) {
  const connectedPlatformSet = useMemo(() => {
    return new Set(accounts.map(account => account.type).filter(isSupportedPlatform))
  }, [accounts])
  const selectableAccountCount = useMemo(() => {
    return accounts.filter(isDemoPublishSelectableAccount).length
  }, [accounts])
  const groupedPlatforms = useMemo(() => {
    const groups: Record<PlatformFilter, PlatformUiMeta[]> = {
      ready: [],
      connected: [],
      plugin: [],
      other: [],
      all: platformInfos,
    }

    platformInfos.forEach((meta) => {
      if (canAuthorizePlatform(meta)) {
        groups.ready.push(meta)
      }
      if (connectedPlatformSet.has(meta.platform)) {
        groups.connected.push(meta)
      }
      if (meta.pluginOnly) {
        groups.plugin.push(meta)
      }
      if (!meta.regionSupported && !meta.pluginOnly) {
        groups.other.push(meta)
      }
    })

    return groups
  }, [connectedPlatformSet, platformInfos])

  return (
    <Card className="min-w-0 bg-card shadow-[0_12px_34px_oklch(0.35_0.035_286_/_0.08)]">
      <CardHeader className="p-4 pb-3">
        <PanelTitle
          icon={<PlugsConnected size={20} weight="duotone" />}
          title="账号连接"
          action={(
            <Button type="button" size="icon" variant="ghost" onClick={onRefreshAccounts} aria-label="刷新账号">
              <ArrowClockwise className={accountsLoading ? 'animate-spin' : ''} size={18} weight="bold" />
            </Button>
          )}
        />
        <CardDescription>{environment.label}使用独立 API Key，切换站点后账号和授权状态会分开加载。</CardDescription>
      </CardHeader>
      <CardContent className="grid gap-4 p-4 pt-0 xl:grid-cols-[minmax(0,1.15fr)_minmax(360px,0.85fr)]">
        <div className="grid min-w-0 gap-4">
          <Tabs defaultValue="ready" className="grid gap-3">
            <TabsList className="flex h-auto flex-wrap items-stretch gap-1 bg-muted/75 p-1">
              <TabsTrigger value="ready" className="min-w-[96px] flex-1 justify-between px-2 text-xs">
                <span>可授权</span>
                <strong>{groupedPlatforms.ready.length}</strong>
              </TabsTrigger>
              <TabsTrigger value="connected" className="min-w-[96px] flex-1 justify-between px-2 text-xs">
                <span>已连接</span>
                <strong>{groupedPlatforms.connected.length}</strong>
              </TabsTrigger>
              <TabsTrigger value="plugin" className="min-w-[86px] flex-1 justify-between px-2 text-xs">
                <span>插件</span>
                <strong>{groupedPlatforms.plugin.length}</strong>
              </TabsTrigger>
              <TabsTrigger value="other" className="min-w-[96px] flex-1 justify-between px-2 text-xs">
                <span>另一区域</span>
                <strong>{groupedPlatforms.other.length}</strong>
              </TabsTrigger>
              <TabsTrigger value="all" className="min-w-[86px] flex-1 justify-between px-2 text-xs">
                <span>全部</span>
                <strong>{groupedPlatforms.all.length}</strong>
              </TabsTrigger>
            </TabsList>

            {(['ready', 'connected', 'plugin', 'other', 'all'] satisfies PlatformFilter[]).map(filter => (
              <TabsContent key={filter} value={filter} className="mt-0">
                <div className="grid max-h-[280px] gap-2 overflow-auto pr-1 xl:max-h-[300px]">
                  {groupedPlatforms[filter].length > 0 ? groupedPlatforms[filter].map(meta => (
                    <PlatformAuthTile
                      key={meta.platform}
                      meta={meta}
                      state={authStates[meta.platform]}
                      onStartAuth={onStartAuth}
                    />
                  )) : (
                    <EmptyState
                      icon={<ShieldCheck size={26} weight="duotone" />}
                      title="这里暂时没有平台"
                      detail="切换筛选或刷新平台元数据"
                    />
                  )}
                </div>
              </TabsContent>
            ))}
          </Tabs>

          {platformMetadataLoading ? (
            <div className="rounded-md border border-border bg-muted/55 p-3 text-sm text-muted-foreground">正在同步平台元数据</div>
          ) : null}

          {platformMetadataError ? (
            <InlineAlert message={`平台元数据加载失败: ${platformMetadataError}`} />
          ) : null}
        </div>

        <Separator className="xl:hidden" />

        <div className="grid min-w-0 gap-4 xl:border-l xl:border-border xl:pl-4">
          <div className="flex items-center justify-between gap-3">
            <div>
              <h3 className="text-sm font-semibold">可发布账号</h3>
              <p className="text-xs text-muted-foreground">小红书和视频号为插件发布，demo 不支持选择</p>
            </div>
            <Badge variant="secondary">{selectableAccountCount}/{accounts.length} 个</Badge>
          </div>

          <div className="grid max-h-[280px] gap-2 overflow-auto pr-1 xl:max-h-[300px]">
            {accountsLoading ? (
              <>
                <SkeletonRow />
                <SkeletonRow />
              </>
            ) : accounts.length > 0 ? (
              accounts.map(account => (
                <AccountRow
                  key={account.id}
                  account={account}
                  platformMetaMap={platformMetaMap}
                  selected={selectedAccountIds.has(account.id) && isDemoPublishSelectableAccount(account)}
                  onToggle={onToggleAccount}
                />
              ))
            ) : (
              <EmptyState
                icon={<Broadcast size={26} weight="duotone" />}
                title="暂无账号"
                detail="先完成当前站点的平台授权"
              />
            )}
          </div>

          {accountsError ? <InlineAlert message={accountsError} /> : null}
        </div>
      </CardContent>
    </Card>
  )
}

interface PlatformAuthTileProps {
  meta: PlatformUiMeta
  state: AuthUiState
  onStartAuth: (platform: Platform) => void
}

function PlatformAuthTile({ meta, state, onStartAuth }: PlatformAuthTileProps) {
  const busy = state.phase === 'starting' || state.phase === 'pending'
  const canStart = canAuthorizePlatform(meta)
  const supportLabel = getPlatformSupportLabel(meta)
  const disabled = busy || !canStart
  const detail = state.message
    || (!canStart ? supportLabel : meta.authInstruction || getAuthTypeText(meta.authType))

  return (
    <article className={`grid gap-3 rounded-md border p-3 transition sm:grid-cols-[minmax(0,1fr)_auto] sm:items-center ${
      canStart
        ? 'border-primary/25 bg-card shadow-sm hover:border-primary/45'
        : 'border-border bg-muted/30'
    }`}>
      <div className="flex min-w-0 items-center gap-3">
        <span className="grid size-10 shrink-0 place-items-center rounded-md border border-border bg-muted/45">
          <PlatformLogo meta={meta} className="size-7" />
        </span>
        <div className="min-w-0">
          <div className="flex flex-wrap items-center gap-2">
            <strong className="truncate text-sm font-semibold">{meta.label}</strong>
            <Badge variant={getAuthBadgeVariant(meta, state)}>{getAuthBadgeText(meta, state)}</Badge>
            <Badge variant="outline" className="bg-card">{getRegionBadgeText(meta)}</Badge>
          </div>
          <p className="mt-1 truncate text-xs text-muted-foreground" title={detail}>{detail}</p>
          {state.expiresAt ? (
            <p className="mt-1 text-xs text-muted-foreground">会话到期 {formatCompactTime(state.expiresAt)}</p>
          ) : null}
        </div>
      </div>

      <div className="flex items-center gap-2">
        <Button
          type="button"
          size="sm"
          variant={canStart ? 'default' : 'secondary'}
          className={canStart ? 'bg-[image:var(--gradientBackColor)]' : ''}
          disabled={disabled}
          onClick={() => onStartAuth(meta.platform)}
          title={canStart ? `授权 ${meta.label}` : supportLabel}
        >
          {busy ? <ArrowClockwise className="animate-spin" size={15} weight="bold" /> : <Link size={15} weight="bold" />}
          {busy ? '轮询中' : '授权'}
        </Button>
        {state.url ? (
          <Button asChild type="button" size="icon" variant="outline" aria-label="打开授权链接">
            <a href={state.url} target="_blank" rel="noreferrer">
              <Eye size={16} weight="bold" />
            </a>
          </Button>
        ) : null}
      </div>
    </article>
  )
}

function getAuthBadgeText(meta: PlatformUiMeta, state: AuthUiState) {
  if (state.phase === 'completed') {
    return '已授权'
  }
  if (state.phase === 'failed') {
    return '失败'
  }
  if (state.phase === 'starting' || state.phase === 'pending') {
    return '轮询'
  }
  return getPlatformSupportLabel(meta)
}

function getAuthBadgeVariant(meta: PlatformUiMeta, state: AuthUiState) {
  if (state.phase === 'completed') {
    return 'success'
  }
  if (state.phase === 'failed') {
    return 'destructive'
  }
  if (state.phase === 'starting' || state.phase === 'pending') {
    return 'warning'
  }
  if (canAuthorizePlatform(meta)) {
    return 'success'
  }
  if (meta.pluginOnly) {
    return 'muted'
  }
  return 'warning'
}

function getAuthTypeText(authType?: string) {
  switch (authType) {
    case 'qrcode':
      return '扫码授权'
    case 'plugin':
      return '仅插件支持'
    case 'browser':
      return '浏览器授权'
    case 'oauth2':
      return 'OAuth 授权'
    default:
      return '等待连接'
  }
}

function getRegionBadgeText(meta: PlatformUiMeta) {
  if (!meta.regionSupported) {
    return getEnvironmentByRegion(meta.region).label
  }

  return meta.region === 'domestic' ? '国内' : '海外'
}

function PlatformLogo({ meta, className }: { meta: PlatformUiMeta, className: string }) {
  const [failed, setFailed] = useState(false)

  return (
    <span className={`${className} relative inline-grid place-items-center overflow-hidden rounded-[6px] bg-primary/10 text-[10px] font-semibold text-primary`}>
      <span>{meta.mark.slice(0, 3)}</span>
      {!failed && meta.logo ? (
        <img
          className="absolute inset-0 size-full object-contain"
          src={meta.logo}
          alt=""
          onError={() => setFailed(true)}
        />
      ) : null}
    </span>
  )
}

interface AccountRowProps {
  account: ChannelAccount
  platformMetaMap: Map<Platform, PlatformUiMeta>
  selected: boolean
  onToggle: (accountId: string) => void
}

function AccountRow({ account, platformMetaMap, selected, onToggle }: AccountRowProps) {
  const meta = getPlatformUiMeta(account.type, platformMetaMap)
  const pluginPublishOnly = isPluginPublishOnlyPlatform(account.type)
  const disabled = account.status !== 1 || pluginPublishOnly
  const badgeText = account.status !== 1 ? '失效' : pluginPublishOnly ? '插件发布' : selected ? '已选' : '可用'
  const badgeVariant = disabled ? 'muted' : selected ? 'success' : 'outline'

  return (
    <button
      className={`grid w-full grid-cols-[42px_minmax(0,1fr)_auto] items-center gap-3 rounded-md border p-3 text-left transition ${
        selected
          ? 'border-primary/45 bg-primary/10 shadow-[inset_0_0_0_1px_oklch(0.74_0.17_3_/_0.12)]'
          : 'border-border bg-card/88 hover:border-primary/30 hover:bg-card'
      } ${disabled ? 'opacity-55' : ''}`}
      type="button"
      disabled={disabled}
      title={pluginPublishOnly ? `${meta.label} 是插件发布平台，demo 不支持选择账号` : undefined}
      onClick={() => onToggle(account.id)}
    >
      <span className="grid size-10 place-items-center overflow-hidden rounded-md border border-border bg-muted text-sm font-semibold text-primary">
        {account.avatar ? <img className="size-full object-cover" src={account.avatar} alt="" /> : meta.mark.slice(0, 1)}
      </span>
      <span className="min-w-0">
        <strong className="block truncate text-sm font-semibold">{account.nickname || account.uid}</strong>
        <span className="block truncate text-xs text-muted-foreground">
          {meta.label}
          {' '}
          {account.uid}
        </span>
      </span>
      <span className="flex items-center gap-2">
        <span className="hidden text-right text-xs text-muted-foreground sm:grid">
          <strong className="text-sm text-foreground">{formatLargeNumber(account.fansCount)}</strong>
          粉丝
        </span>
        <Badge variant={badgeVariant}>
          {!disabled && selected ? <Check size={12} weight="bold" /> : null}
          {badgeText}
        </Badge>
      </span>
    </button>
  )
}

interface ContentPanelProps {
  contentDraft: ContentDraft
  mediaUpload: UploadState
  coverUpload: UploadState
  onContentChange: (patch: Partial<ContentDraft>) => void
  onUploadFile: (kind: 'media' | 'cover', file: File) => void
}

function ContentPanel({
  contentDraft,
  mediaUpload,
  coverUpload,
  onContentChange,
  onUploadFile,
}: ContentPanelProps) {
  return (
    <Card className="min-w-0 bg-card shadow-[0_12px_34px_oklch(0.35_0.035_286_/_0.08)]">
      <CardHeader className="p-4 pb-3">
        <PanelTitle
          icon={<FilmSlate size={20} weight="duotone" />}
          title="发布内容"
          action={<Badge variant="secondary">{contentDraft.mediaType === 'video' ? 'Video' : 'Image'}</Badge>}
        />
        <CardDescription>上传素材或粘贴已上传资源 URL，发布前会在右侧生成请求体。</CardDescription>
      </CardHeader>

      <CardContent className="grid gap-5 p-4 pt-0">
        <div className="grid gap-4 2xl:grid-cols-[minmax(0,1.1fr)_minmax(300px,0.9fr)]">
          <div className="grid gap-3 rounded-lg border border-border bg-muted/20 p-4">
            <div>
              <h3 className="text-sm font-semibold">文案</h3>
              <p className="text-xs text-muted-foreground">标题、正文和话题会作为公共内容下发到目标账号。</p>
            </div>
            <Label>
              <span>标题</span>
              <Input
                value={contentDraft.title}
                onChange={event => onContentChange({ title: event.target.value })}
                maxLength={80}
              />
            </Label>

            <Label>
              <span>正文</span>
              <Textarea
                value={contentDraft.body}
                onChange={event => onContentChange({ body: event.target.value })}
                rows={9}
                className="min-h-52"
              />
            </Label>

            <Label>
              <span>话题</span>
              <Input
                value={DEMO_TOPIC}
                readOnly
              />
            </Label>
          </div>

          <div className="grid content-start gap-3 rounded-lg border border-border bg-card p-4">
            <div>
              <h3 className="text-sm font-semibold">素材与排期</h3>
              <p className="text-xs text-muted-foreground">上传后会自动回填 URL，也可以直接粘贴已有资源。</p>
            </div>
            <div className="grid gap-3 sm:grid-cols-2 2xl:grid-cols-1">
              <UploadBox
                kind="media"
                title="媒体文件"
                uploadState={mediaUpload}
                onUploadFile={onUploadFile}
              />

              <UploadBox
                kind="cover"
                title="封面图片"
                uploadState={coverUpload}
                onUploadFile={onUploadFile}
              />
            </div>

            <Label>
              <span>媒体 URL</span>
              <Input
                value={contentDraft.mediaUrl}
                onChange={(event) => {
                  const value = event.target.value
                  onContentChange({
                    mediaUrl: value,
                    mediaType: value ? inferMediaType(value) : contentDraft.mediaType,
                  })
                }}
                placeholder="https://assets.aitoearn.cn/..."
              />
            </Label>

            <Label>
              <span>封面 URL</span>
              <Input
                value={contentDraft.coverUrl}
                onChange={event => onContentChange({ coverUrl: event.target.value })}
                placeholder="https://assets.aitoearn.cn/..."
              />
            </Label>

            <Label>
              <span>发布时间</span>
              <Input
                type="datetime-local"
                value={toDateTimeLocalValue(contentDraft.publishAt)}
                onChange={event => onContentChange({ publishAt: fromDateTimeLocalValue(event.target.value) })}
              />
            </Label>
          </div>
        </div>
      </CardContent>
    </Card>
  )
}

interface UploadBoxProps {
  kind: 'media' | 'cover'
  title: string
  uploadState: UploadState
  onUploadFile: (kind: 'media' | 'cover', file: File) => void
}

function UploadBox({ kind, title, uploadState, onUploadFile }: UploadBoxProps) {
  const inputId = `upload-${kind}`
  const active = uploadState.status !== 'idle'

  return (
    <label
      className={`relative grid min-h-[112px] cursor-pointer gap-3 overflow-hidden rounded-md border p-3 transition ${
        active ? 'border-primary/45 bg-primary/10' : 'border-border bg-muted/35 hover:border-primary/35 hover:bg-card'
      }`}
      htmlFor={inputId}
    >
      <input
        id={inputId}
        className="sr-only"
        type="file"
        accept={kind === 'cover' ? 'image/*' : 'video/*,image/*'}
        onChange={(event) => {
          const file = event.target.files?.[0]
          if (file) {
            onUploadFile(kind, file)
          }
          event.currentTarget.value = ''
        }}
      />
      <span className="flex items-center gap-2">
        <span className="grid size-9 place-items-center rounded-md bg-[image:var(--gradientBackColor)] text-primary-foreground">
          <CloudArrowUp size={20} weight="duotone" />
        </span>
        <span className="min-w-0">
          <strong className="block truncate text-sm">{title}</strong>
          <span className="block truncate text-xs text-muted-foreground">{uploadState.fileName || '点击上传'}</span>
        </span>
      </span>
      <span className="text-xs text-muted-foreground">{getUploadText(uploadState)}</span>
      <span className="absolute inset-x-0 bottom-0 h-1 bg-muted">
        <span
          className="block h-full bg-[image:var(--gradientBackColor)] transition-[width] duration-200"
          style={{ width: `${uploadState.progress}%` }}
        />
      </span>
      {uploadState.status === 'error' ? (
        <span className="text-xs text-destructive">{uploadState.error}</span>
      ) : null}
    </label>
  )
}

function getUploadText(uploadState: UploadState) {
  switch (uploadState.status) {
    case 'signing':
      return '签名中'
    case 'uploading':
      return `${uploadState.progress}%`
    case 'confirming':
      return '确认中'
    case 'done':
      return '完成'
    case 'error':
      return uploadState.error || '失败'
    default:
      return '待上传'
  }
}

interface PublishInspectorProps {
  selectedAccounts: ChannelAccount[]
  contentDraft: ContentDraft
  platformMetaMap: Map<Platform, PlatformUiMeta>
  platformOptions: PlatformOptionsDraft
  publishOptionValues: Record<string, PublishOptionValuesState>
  previewPayload: unknown
  requestJson: string
  publishError: string
  publishErrorDetail: ApiResponse<PublishValidationErrorData> | null
  activeTab: PublishInspectorTab
  publishing: boolean
  onPlatformOptionChange: (platform: Platform, patch: PlatformOptionDraft) => void
  onLoadOptionValues: (accountId: string, field: string, params?: Record<string, string>) => void
  onCopyJson: () => void
  onPublish: () => void
  onTabChange: (value: PublishInspectorTab) => void
  flow: ChannelPublishFlow | null
  records: Record<string, ChannelPublishRecord>
  douyinActions: Record<string, DouyinUserActionState>
  onOpenDouyinAction: (taskId: string) => void
  onRefresh: () => void
}

function PublishInspector({
  selectedAccounts,
  contentDraft,
  platformMetaMap,
  platformOptions,
  publishOptionValues,
  previewPayload,
  requestJson,
  publishError,
  publishErrorDetail,
  activeTab,
  publishing,
  onPlatformOptionChange,
  onLoadOptionValues,
  onCopyJson,
  onPublish,
  onTabChange,
  flow,
  records,
  douyinActions,
  onOpenDouyinAction,
  onRefresh,
}: PublishInspectorProps) {
  const jsonValue = requestJson || (previewPayload ? JSON.stringify(previewPayload, null, 2) : '{\n  "items": []\n}')

  return (
    <Card className="min-w-0 bg-card shadow-[0_16px_44px_oklch(0.35_0.045_286_/_0.10)] 2xl:sticky 2xl:top-5">
      <CardHeader className="p-4 pb-3">
        <PanelTitle
          icon={<PaperPlaneTilt size={20} weight="duotone" />}
          title="发布检查器"
          action={<Badge variant={selectedAccounts.length > 0 ? 'success' : 'warning'}>{selectedAccounts.length} 个目标</Badge>}
        />
        <CardDescription>检查目标账号、平台参数、请求体和任务状态。</CardDescription>
      </CardHeader>

      <CardContent className="grid gap-4 p-4 pt-0">
        <Tabs value={activeTab} onValueChange={value => onTabChange(value as PublishInspectorTab)} className="grid gap-4">
          <TabsList className="grid h-auto grid-cols-3">
            <TabsTrigger value="route">目标</TabsTrigger>
            <TabsTrigger value="request">请求体</TabsTrigger>
            <TabsTrigger value="status">状态</TabsTrigger>
          </TabsList>

          <TabsContent value="route" className="mt-0 grid gap-4">
            <PlatformOptionsPanel
              selectedAccounts={selectedAccounts}
              contentDraft={contentDraft}
              platformOptions={platformOptions}
              platformMetaMap={platformMetaMap}
              optionValues={publishOptionValues}
              onChange={onPlatformOptionChange}
              onLoadOptionValues={onLoadOptionValues}
            />
          </TabsContent>

          <TabsContent value="request" className="mt-0 grid gap-3">
            <div className="flex items-center justify-between gap-3">
              <div>
                <h3 className="text-sm font-semibold">请求体</h3>
                <p className="text-xs text-muted-foreground">发布前可复制用于接口调试</p>
              </div>
              <Button type="button" size="sm" variant="outline" onClick={onCopyJson}>
                <Copy size={15} weight="bold" />
                复制
              </Button>
            </div>
            <pre className="max-h-[460px] min-h-[280px] overflow-auto rounded-md border border-border bg-[#fbfcff] p-3 font-mono text-xs leading-6 text-foreground">
              {jsonValue}
            </pre>
          </TabsContent>

          <TabsContent value="status" className="mt-0">
            <StatusContent
              flow={flow}
              records={records}
              platformMetaMap={platformMetaMap}
              publishing={publishing}
              douyinActions={douyinActions}
              onOpenDouyinAction={onOpenDouyinAction}
              onRefresh={onRefresh}
            />
          </TabsContent>
        </Tabs>

        {publishError ? (
          publishErrorDetail ? (
            <PublishErrorDetail
              message={publishError}
              detail={publishErrorDetail}
              selectedAccounts={selectedAccounts}
              platformMetaMap={platformMetaMap}
            />
          ) : (
            <InlineAlert message={publishError} />
          )
        ) : null}

        <Button className="h-12 bg-[image:var(--gradientBackColor)]" type="button" disabled={publishing} onClick={onPublish}>
          {publishing ? <ArrowClockwise className="animate-spin" size={19} weight="bold" /> : <Play size={19} weight="fill" />}
          {publishing ? '发布中' : '创建发布 Flow'}
        </Button>
      </CardContent>
    </Card>
  )
}

interface PublishErrorDetailProps {
  message: string
  detail: ApiResponse<PublishValidationErrorData>
  selectedAccounts: ChannelAccount[]
  platformMetaMap: Map<Platform, PlatformUiMeta>
}

function PublishErrorDetail({ message, detail, selectedAccounts, platformMetaMap }: PublishErrorDetailProps) {
  const data = detail.data
  const platform = data?.platform
  const account = data?.accountId
    ? selectedAccounts.find(item => item.id === data.accountId)
    : undefined
  const meta = platform ? getPlatformUiMeta(platform, platformMetaMap) : undefined
  const issues = data?.issues || []

  return (
    <section className="grid gap-3 rounded-lg border border-destructive/25 bg-destructive/10 p-3 text-sm text-foreground">
      <div className="flex items-start gap-2">
        <WarningCircle className="mt-0.5 size-5 shrink-0 text-destructive" weight="bold" />
        <div className="min-w-0">
          <h3 className="font-semibold text-destructive">{message}</h3>
          <div className="mt-1 flex flex-wrap gap-2 text-xs text-muted-foreground">
            <span>code: {detail.code}</span>
            {detail.requestId ? <span>requestId: {detail.requestId}</span> : null}
            {detail.timestamp ? <span>{formatErrorTime(detail.timestamp)}</span> : null}
          </div>
        </div>
      </div>

      {platform || account ? (
        <div className="grid gap-2 rounded-md border border-destructive/20 bg-card/80 p-2 text-xs">
          {platform ? (
            <div className="flex items-center justify-between gap-3">
              <span className="text-muted-foreground">平台</span>
              <span className="font-medium">{meta?.label || platform}</span>
            </div>
          ) : null}
          {data?.accountId ? (
            <div className="flex items-center justify-between gap-3">
              <span className="text-muted-foreground">账号</span>
              <span className="truncate font-medium">{account?.nickname || data.accountId}</span>
            </div>
          ) : null}
        </div>
      ) : null}

      {issues.length > 0 ? (
        <div className="grid gap-2">
          {issues.map((issue, index) => (
            <div key={`${issue.code || 'issue'}-${index}`} className="grid gap-2 rounded-md border border-destructive/20 bg-card p-2">
              <div className="flex flex-wrap items-center gap-2">
                <Badge variant="destructive">{issue.code || 'validation'}</Badge>
                <strong className="text-sm">{issue.message || '参数校验失败'}</strong>
              </div>
              <div className="flex flex-wrap gap-2 text-xs text-muted-foreground">
                {issue.path?.length ? <span>path: {issue.path.join('.')}</span> : null}
                {formatIssueParams(issue.params).map(item => (
                  <span key={item}>{item}</span>
                ))}
              </div>
            </div>
          ))}
        </div>
      ) : null}
    </section>
  )
}

function formatIssueParams(params?: Record<string, unknown>) {
  if (!params) {
    return []
  }

  return Object.entries(params)
    .filter(([, value]) => value !== undefined && value !== null && value !== '')
    .map(([key, value]) => `${key}: ${String(value)}`)
}

function formatErrorTime(timestamp: number) {
  return new Intl.DateTimeFormat('zh-CN', {
    month: '2-digit',
    day: '2-digit',
    hour: '2-digit',
    minute: '2-digit',
    second: '2-digit',
  }).format(new Date(timestamp))
}

function getDouyinActionBadgeText(action?: DouyinUserActionState) {
  switch (action?.status) {
    case 'ready':
      return '扫码发布'
    case 'loading':
      return '准备扫码'
    case 'error':
      return '入口失败'
    default:
      return '等待扫码'
  }
}

function getDouyinActionHint(action?: DouyinUserActionState) {
  switch (action?.status) {
    case 'ready':
      return '点击打开二维码，使用抖音 App 扫码完成发布。'
    case 'loading':
      return '正在准备抖音扫码入口...'
    case 'error':
      return action.error || '抖音扫码入口获取失败，点击重试。'
    default:
      return '正在等待抖音返回扫码入口，点击可立即检查。'
  }
}

function getQrCodeImageUrl(value: string) {
  return `https://api.qrserver.com/v1/create-qr-code/?size=280x280&margin=12&data=${encodeURIComponent(value)}`
}

interface DouyinQRCodeModalProps {
  action: DouyinUserActionState | null
  onClose: () => void
}

function DouyinQRCodeModal({ action, onClose }: DouyinQRCodeModalProps) {
  if (!action) {
    return null
  }

  const ready = action.status === 'ready'
  const qrValue = ready ? action.shortLink : ''

  return (
    <div className="fixed inset-0 z-50 grid place-items-center bg-slate-950/35 px-4 py-6 backdrop-blur-sm" role="dialog" aria-modal="true">
      <div className="w-full max-w-[420px] rounded-lg border border-border bg-card p-4 shadow-[0_24px_80px_oklch(0.35_0.045_286_/_0.22)]">
        <div className="flex items-start justify-between gap-4">
          <div className="flex items-center gap-3">
            <span className="grid size-10 place-items-center rounded-md bg-[image:var(--gradientBackColor)] text-primary-foreground">
              <QrCode size={22} weight="bold" />
            </span>
            <div>
              <h2 className="text-base font-semibold">抖音扫码发布</h2>
              <p className="text-xs text-muted-foreground">扫码后 demo 会继续轮询发布结果。</p>
            </div>
          </div>
          <Button type="button" size="icon" variant="ghost" onClick={onClose} aria-label="关闭">
            <X size={18} weight="bold" />
          </Button>
        </div>

        <div className="mt-4 grid justify-items-center gap-4">
          <div className="grid size-[304px] place-items-center rounded-lg border border-border bg-white p-3 shadow-sm">
            {ready ? (
              <img
                className="size-[280px]"
                src={getQrCodeImageUrl(qrValue)}
                alt="抖音扫码发布二维码"
              />
            ) : (
              <div className="grid justify-items-center gap-2 text-center text-sm text-muted-foreground">
                <ArrowClockwise className={action.status === 'loading' ? 'animate-spin text-primary' : 'text-destructive'} size={24} weight="bold" />
                <span>{getDouyinActionHint(action)}</span>
              </div>
            )}
          </div>

          <div className="grid gap-1 text-center">
            <p className="text-sm font-medium">
              {ready ? '使用抖音 App 扫码，确认后完成发布。' : '正在等待抖音发布入口'}
            </p>
            <p className="text-xs text-muted-foreground">完成扫码发布后，状态会自动更新为已发布。</p>
            {ready && action.expiresAt ? (
              <p className="text-xs text-muted-foreground">入口有效期至 {formatCompactTime(action.expiresAt)}</p>
            ) : null}
          </div>

          {ready ? (
            <Button type="button" variant="outline" className="w-full" asChild>
              <a href={action.shortLink} target="_blank" rel="noreferrer">
                <Link size={16} weight="bold" />
                打开发布链接
              </a>
            </Button>
          ) : null}
        </div>
      </div>
    </div>
  )
}

interface StatusContentProps {
  flow: ChannelPublishFlow | null
  records: Record<string, ChannelPublishRecord>
  platformMetaMap: Map<Platform, PlatformUiMeta>
  publishing: boolean
  douyinActions: Record<string, DouyinUserActionState>
  onOpenDouyinAction: (taskId: string) => void
  onRefresh: () => void
}

function StatusContent({
  flow,
  records,
  platformMetaMap,
  publishing,
  douyinActions,
  onOpenDouyinAction,
  onRefresh,
}: StatusContentProps) {
  return (
    <div className="grid gap-3">
      <div className="flex items-center justify-between gap-3">
          <div>
            <h3 className="text-sm font-semibold">任务状态</h3>
            <p className="text-xs text-muted-foreground">创建 Flow 后自动轮询，抖音扫码完成后会自动更新。</p>
          </div>
        <Button type="button" size="sm" variant="outline" onClick={onRefresh} disabled={!flow}>
          <ArrowClockwise className={publishing ? 'animate-spin' : ''} size={15} weight="bold" />
          刷新
        </Button>
      </div>

      {flow ? (
        <>
          <div className="grid gap-1 rounded-md border border-border bg-muted/35 p-3">
            <span className="text-xs text-muted-foreground">Flow ID</span>
            <strong className="break-all font-mono text-xs">{flow.flowId}</strong>
          </div>
          <div className="grid max-h-[440px] gap-2 overflow-auto pr-1">
            {flow.tasks.map((task) => {
              const record = records[task.id]
              const status = getRecordStatus(task.status, record)
              const meta = getPlatformUiMeta(task.platform, platformMetaMap)
              const douyinAction = douyinActions[task.id]
              const douyinActionActive = canUseDouyinAction(task.platform, status, douyinAction)
              const badgeVariant = douyinAction?.status === 'error' ? 'destructive' : getPublishBadgeVariant(status)
              const badgeText = douyinActionActive
                ? getDouyinActionBadgeText(douyinAction)
                : getStatusText(status)
              return (
                <article
                  className={`grid gap-3 rounded-md border p-3 transition sm:grid-cols-[32px_minmax(0,1fr)_auto] sm:items-start ${
                    douyinActionActive
                      ? 'cursor-pointer border-primary/35 bg-primary/5 hover:border-primary/55 hover:bg-primary/10'
                      : 'border-border bg-card'
                  }`}
                  key={task.id}
                  role={douyinActionActive ? 'button' : undefined}
                  tabIndex={douyinActionActive ? 0 : undefined}
                  onClick={douyinActionActive ? () => onOpenDouyinAction(task.id) : undefined}
                  onKeyDown={douyinActionActive
                    ? (event) => {
                        if (event.key === 'Enter' || event.key === ' ') {
                          event.preventDefault()
                          onOpenDouyinAction(task.id)
                        }
                      }
                    : undefined}
                >
                  <PlatformLogo meta={meta} className="size-8" />
                  <div className="min-w-0">
                    <strong className="block truncate text-sm">{meta.label}</strong>
                    <span className="block break-all font-mono text-xs text-muted-foreground">{task.id}</span>
                    {task.publishTime || record?.publishedAt ? (
                      <span className="mt-1 block text-xs text-muted-foreground">
                        {formatCompactTime(task.publishTime || record?.publishedAt)}
                      </span>
                    ) : null}
                    {record?.workLink ? (
                      <a className="mt-2 inline-flex text-xs font-medium text-primary" href={record.workLink} target="_blank" rel="noreferrer">
                        查看作品
                      </a>
                    ) : null}
                    {record?.errorMsg || task.errorMsg ? (
                      <p className="mt-2 text-xs text-destructive">{record?.errorMsg || task.errorMsg}</p>
                    ) : null}
                    {douyinActionActive ? (
                      <p className={`mt-2 text-xs font-medium ${douyinAction?.status === 'error' ? 'text-destructive' : 'text-primary'}`}>
                        {getDouyinActionHint(douyinAction)}
                      </p>
                    ) : null}
                  </div>
                  <Badge variant={badgeVariant}>{badgeText}</Badge>
                </article>
              )
            })}
          </div>
        </>
      ) : (
        <EmptyState
          icon={<PaperPlaneTilt size={28} weight="duotone" />}
          title="等待 Flow"
          detail="创建发布后这里显示任务状态"
        />
      )}
    </div>
  )
}

interface StatusPanelProps {
  flow: ChannelPublishFlow | null
  records: Record<string, ChannelPublishRecord>
  platformMetaMap: Map<Platform, PlatformUiMeta>
  publishing: boolean
  onRefresh: () => void
}

function StatusPanel({ flow, records, platformMetaMap, publishing, onRefresh }: StatusPanelProps) {
  return (
    <Card className="min-w-0 bg-card/88 shadow-sm backdrop-blur">
      <CardHeader className="p-4 pb-3">
        <PanelTitle
          icon={<Broadcast size={20} weight="duotone" />}
          title="发布状态"
          action={(
            <Button type="button" size="icon" variant="ghost" onClick={onRefresh} disabled={!flow} aria-label="刷新状态">
              <ArrowClockwise className={publishing ? 'animate-spin' : ''} size={18} weight="bold" />
            </Button>
          )}
        />
      </CardHeader>
      <CardContent className="grid gap-3 p-4 pt-0">
        {flow ? (
          <>
            <div className="grid gap-1 rounded-md border border-border bg-muted/40 p-3">
              <span className="text-xs text-muted-foreground">Flow ID</span>
              <strong className="break-all font-mono text-xs">{flow.flowId}</strong>
            </div>
            <div className="grid gap-2">
              {flow.tasks.map((task) => {
                const record = records[task.id]
                const status = getRecordStatus(task.status, record)
                const meta = getPlatformUiMeta(task.platform, platformMetaMap)
                return (
                  <article className="grid gap-3 rounded-md border border-border bg-card p-3 sm:grid-cols-[32px_minmax(0,1fr)_auto] sm:items-start" key={task.id}>
                    <PlatformLogo meta={meta} className="size-8" />
                    <div className="min-w-0">
                      <strong className="block truncate text-sm">{meta.label}</strong>
                      <span className="block break-all font-mono text-xs text-muted-foreground">{task.id}</span>
                      {task.publishTime || record?.publishedAt ? (
                        <span className="mt-1 block text-xs text-muted-foreground">
                          {formatCompactTime(task.publishTime || record?.publishedAt)}
                        </span>
                      ) : null}
                      {record?.workLink ? (
                        <a className="mt-2 inline-flex text-xs font-medium text-primary" href={record.workLink} target="_blank" rel="noreferrer">
                          查看作品
                        </a>
                      ) : null}
                      {record?.errorMsg || task.errorMsg ? (
                        <p className="mt-2 text-xs text-destructive">{record?.errorMsg || task.errorMsg}</p>
                      ) : null}
                    </div>
                    <Badge variant={getPublishBadgeVariant(status)}>{getStatusText(status)}</Badge>
                  </article>
                )
              })}
            </div>
          </>
        ) : (
          <EmptyState
            icon={<PaperPlaneTilt size={28} weight="duotone" />}
            title="等待 Flow"
            detail="创建发布后这里显示任务状态"
          />
        )}
      </CardContent>
    </Card>
  )
}

function getPublishBadgeVariant(status?: number) {
  switch (status) {
    case 1:
    case 7:
      return 'success'
    case -1:
    case 5:
    case 9:
      return 'destructive'
    case 2:
    case 6:
    case 8:
      return 'warning'
    default:
      return 'secondary'
  }
}

interface PanelTitleProps {
  icon: ReactNode
  title: string
  action?: ReactNode
}

function PanelTitle({ icon, title, action }: PanelTitleProps) {
  return (
    <div className="flex items-center justify-between gap-3">
      <div className="flex min-w-0 items-center gap-2">
        <span className="grid size-9 shrink-0 place-items-center rounded-md border border-border bg-muted text-primary">{icon}</span>
        <CardTitle className="truncate">{title}</CardTitle>
      </div>
      {action ? <div className="shrink-0">{action}</div> : null}
    </div>
  )
}

interface EmptyStateProps {
  icon: ReactNode
  title: string
  detail: string
}

function EmptyState({ icon, title, detail }: EmptyStateProps) {
  return (
    <div className="grid min-h-28 place-items-center gap-1 rounded-md border border-dashed border-border bg-muted/35 p-4 text-center">
      <span className="text-primary">{icon}</span>
      <strong className="text-sm">{title}</strong>
      <span className="text-xs text-muted-foreground">{detail}</span>
    </div>
  )
}

function InlineAlert({ message }: { message: string }) {
  return (
    <div className="flex items-start gap-2 rounded-md border border-destructive/25 bg-destructive/10 p-3 text-sm text-destructive">
      <WarningCircle className="mt-0.5 shrink-0" size={17} weight="fill" />
      <span>{message}</span>
    </div>
  )
}

function SkeletonRow() {
  return (
    <div className="grid grid-cols-[42px_minmax(0,1fr)] items-center gap-3 rounded-md border border-border bg-card p-3">
      <span className="size-10 animate-pulse rounded-md bg-muted" />
      <span className="grid gap-2">
        <span className="h-3 w-2/3 animate-pulse rounded bg-muted" />
        <span className="h-3 w-1/3 animate-pulse rounded bg-muted" />
      </span>
    </div>
  )
}

export default App
