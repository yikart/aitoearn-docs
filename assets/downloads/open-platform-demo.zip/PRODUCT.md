# Product

## Register

product

## Users

开发者、集成方和内部产品同学，用这个 demo 验证 AiToEarn 开放平台账号授权、素材上传、分发发布和状态查询链路。

## Product Purpose

提供一个单页 React demo，最小化配置成本，清楚展示国内站和海外站的 API Key、平台授权范围、账号选择、发布请求和任务状态。

## Brand Personality

高质感、清晰、技术可信。界面可以有发布控制台的视觉张力，但交互必须直接服务调试和验证流程。

## Anti-references

避免营销落地页、空洞炫技、默认模板感、含糊的“不支持”状态、混乱的 API Key 作用域和看不出下一步的表单流程。

## Design Principles

1. 环境先行，先让用户明确当前连接的是国内站还是海外站。
2. 状态可解释，每个平台都说明是当前站可授权、另一区域支持，还是仅插件支持。
3. 发布路径可预览，账号、内容、平台参数和请求体要放在同一条操作流里。
4. 调试不隐藏细节，错误、轮询、Flow 和任务记录都直接展示。
5. 视觉有张力但不过度，动效只用于状态反馈和层级引导。

## Accessibility & Inclusion

默认按 WCAG AA 对比度处理，支持键盘焦点、明确禁用原因和 `prefers-reduced-motion` 降级。
