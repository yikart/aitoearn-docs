import type { InputHTMLAttributes } from 'react'
import { cn } from '../../lib/utils'

export function Input({ className, type, ...props }: InputHTMLAttributes<HTMLInputElement>) {
  return (
    <input
      type={type}
      className={cn(
        'flex h-11 w-full min-w-0 rounded-md border border-input-border bg-card px-3 py-2 text-sm text-foreground shadow-[inset_0_1px_2px_oklch(0.35_0.03_286_/_0.08)] outline-none transition-[border-color,box-shadow,background] placeholder:text-muted-foreground hover:border-primary/40 focus-visible:border-ring focus-visible:bg-background focus-visible:ring-[3px] focus-visible:ring-ring/30 disabled:cursor-not-allowed disabled:opacity-50',
        className,
      )}
      {...props}
    />
  )
}
