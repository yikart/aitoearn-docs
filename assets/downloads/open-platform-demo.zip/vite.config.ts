import type { IncomingHttpHeaders, IncomingMessage, ServerResponse } from 'node:http'
import tailwindcss from '@tailwindcss/vite'
import react from '@vitejs/plugin-react'
import { defineConfig } from 'vite'

const uploadHostAllowList = [
  'cloudflarestorage.com',
  'aliyuncs.com',
  'amazonaws.com',
]

function getHeaderValue(headers: IncomingHttpHeaders, key: string) {
  const value = headers[key]
  return Array.isArray(value) ? value[0] : value
}

function isAllowedUploadTarget(target: URL) {
  if (target.protocol !== 'https:') {
    return false
  }

  return uploadHostAllowList.some((suffix) => {
    return target.hostname === suffix || target.hostname.endsWith(`.${suffix}`)
  })
}

function getUploadTarget(req: IncomingMessage) {
  const requestUrl = new URL(req.url || '', 'http://localhost')
  const target = requestUrl.searchParams.get('target')
  if (!target) {
    return undefined
  }

  try {
    const targetUrl = new URL(target)
    return isAllowedUploadTarget(targetUrl) ? targetUrl : undefined
  }
  catch {
    return undefined
  }
}

function setJsonResponse(res: ServerResponse, statusCode: number, message: string) {
  res.statusCode = statusCode
  res.setHeader('Content-Type', 'application/json; charset=utf-8')
  res.end(JSON.stringify({ message }))
}

async function handleUploadProxy(req: IncomingMessage, res: ServerResponse) {
  if (req.method !== 'PUT' && req.method !== 'POST') {
    setJsonResponse(res, 405, 'upload proxy only accepts PUT or POST')
    return
  }

  const target = getUploadTarget(req)
  if (!target) {
    setJsonResponse(res, 400, 'invalid upload target')
    return
  }

  const headers = new Headers()
  const contentType = getHeaderValue(req.headers, 'content-type')
  const contentLength = getHeaderValue(req.headers, 'content-length')

  if (contentType) {
    headers.set('content-type', contentType)
  }
  if (contentLength) {
    headers.set('content-length', contentLength)
  }

  try {
    const upstream = await fetch(target, {
      method: req.method,
      headers,
      body: req,
      duplex: 'half',
    } as RequestInit & { duplex: 'half' })

    res.statusCode = upstream.status
    const responseText = await upstream.text()
    res.end(responseText)
  }
  catch (error) {
    setJsonResponse(
      res,
      502,
      error instanceof Error ? error.message : 'upload proxy request failed',
    )
  }
}

export default defineConfig(() => {
  return {
    plugins: [
      {
        name: 'aitoearn-upload-proxy',
        configureServer(server) {
          server.middlewares.use('/upload-proxy', (req, res) => {
            void handleUploadProxy(req, res)
          })
        },
      },
      react(),
      tailwindcss(),
    ],
    server: {
      port: 5173,
      proxy: {
        '/cn-api': {
          target: 'https://aitoearn.cn',
          changeOrigin: true,
          secure: false,
          rewrite: path => path.replace(/^\/cn-api/, '/api'),
        },
        '/global-api': {
          target: 'https://aitoearn.ai',
          changeOrigin: true,
          secure: false,
          rewrite: path => path.replace(/^\/global-api/, '/api'),
        },
        '/api': {
          target: 'https://aitoearn.cn',
          changeOrigin: true,
          secure: false,
        },
      },
    },
  }
})
