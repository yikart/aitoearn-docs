# AiToEarn Open Platform Demo

最小可运行的 React 单页 demo，用于跑通 AiToEarn 开放平台的全平台账号授权和发布分发链路。

## 运行

```bash
npm install
npm run dev
```

默认访问：

```text
http://localhost:5173/
```

## 代理

前端通过 Vite 代理访问开放平台，避免浏览器跨域。页面可在顶部切换国内站和海外站：

- `/cn-api/*` 代理到 `https://aitoearn.cn/api/*`
- `/global-api/*` 代理到 `https://aitoearn.ai/api/*`
- `/upload-proxy?target=...` 代理对象存储直传地址，用于规避本地浏览器访问 R2/OSS/S3 预签名 URL 的 CORS 预检问题。

授权接口的 `redirectUri` 会跟随当前站点：

- 国内站回调到 `https://aitoearn.cn`
- 海外站回调到 `https://aitoearn.ai`

不要把授权回调填成 `http://localhost:5173/`。

## 使用流程

1. 打开页面后会先通过当前站点代理拉取 `/api/v2/channels/platforms` 平台元数据。
2. 在页面顶部选择国内站或海外站。两个站点的 `X-Api-Key` 会分别保存。
3. 点击任意平台授权，页面会自动轮询授权状态并刷新账号。
4. 上传媒体和封面，或直接粘贴已上传资源 URL。
5. 选择目标账号。B 站账号会自动加载分区参数。
6. 点击创建发布 Flow，右侧查看记录状态。

平台说明：

- `https://aitoearn.cn` 仅支持国内平台。
- `https://aitoearn.ai` 仅支持海外平台。
- 元数据里 `authType=plugin` 的平台会显示为“仅插件支持”，demo 不发起网页授权。

开放平台文档：https://docs.aitoearn.cn/
