import type {
  ApiResponse,
  AssetVo,
  ChannelAccountAuthStart,
  ChannelAccountAuthStatus,
  ChannelAccountList,
  ChannelCreatePublishFlowParams,
  ChannelPublishFlow,
  ChannelPublishRecord,
  ChannelPublishUserAction,
  Platform,
  PlatformMetadata,
  PublishOptionValues,
  UploadSignData,
} from '../types'

export class OpenPlatformApiError<T = unknown> extends Error {
  payload: ApiResponse<T>
  status: number

  constructor(payload: ApiResponse<T>, status: number) {
    super(payload.message || `HTTP ${status}`)
    this.name = 'OpenPlatformApiError'
    this.payload = payload
    this.status = status
  }
}

function isApiSuccess<T>(response: ApiResponse<T>) {
  return Number(response.code) === 0
}

function createHeaders(apiKey: string, extra?: HeadersInit) {
  return {
    'X-Api-Key': apiKey,
    ...extra,
  }
}

function createOptionalHeaders(apiKey?: string, extra?: HeadersInit) {
  const trimmedApiKey = apiKey?.trim()
  return {
    ...(trimmedApiKey ? { 'X-Api-Key': trimmedApiKey } : {}),
    ...extra,
  }
}

async function parseApiResponse<T>(response: Response): Promise<ApiResponse<T>> {
  const payload = (await response.json()) as ApiResponse<T>

  if (!response.ok) {
    throw new OpenPlatformApiError(payload, response.status)
  }

  if (!isApiSuccess(payload)) {
    throw new OpenPlatformApiError(payload, response.status)
  }

  return payload
}

async function requestApi<T>(
  apiBase: string,
  apiKey: string,
  path: string,
  init?: RequestInit,
): Promise<T> {
  if (!apiKey.trim()) {
    throw new Error('请先填写 X-Api-Key')
  }

  const response = await fetch(`${apiBase}${path}`, {
    ...init,
    headers: createHeaders(apiKey, {
      ...(init?.body ? { 'Content-Type': 'application/json' } : {}),
      ...init?.headers,
    }),
  })

  return parseApiResponse<T>(response).then(result => result.data)
}

async function requestOptionalApi<T>(
  apiBase: string,
  path: string,
  apiKey?: string,
  init?: RequestInit,
): Promise<T> {
  const response = await fetch(`${apiBase}${path}`, {
    ...init,
    headers: createOptionalHeaders(apiKey, {
      ...(init?.body ? { 'Content-Type': 'application/json' } : {}),
      ...init?.headers,
    }),
  })

  return parseApiResponse<T>(response).then(result => result.data)
}

export function getPlatforms(apiBase: string, apiKey?: string, fresh = false) {
  return requestOptionalApi<PlatformMetadata[]>(
    apiBase,
    '/v2/channels/platforms',
    apiKey,
    fresh ? { cache: 'no-store' } : undefined,
  )
}

export function getAccounts(apiBase: string, apiKey: string) {
  return requestApi<ChannelAccountList>(
    apiBase,
    apiKey,
    '/v2/channels/accounts',
  )
}

export function startAccountAuth(apiBase: string, apiKey: string, platform: Platform, redirectUri: string) {
  const query = new URLSearchParams({ redirectUri })
  return requestApi<ChannelAccountAuthStart>(
    apiBase,
    apiKey,
    `/v2/channels/accounts/auth/${platform}?${query.toString()}`,
  )
}

export function getAuthStatus(apiBase: string, apiKey: string, platform: Platform, sessionId: string) {
  return requestApi<ChannelAccountAuthStatus>(
    apiBase,
    apiKey,
    `/v2/channels/accounts/auth/${platform}/status/${encodeURIComponent(sessionId)}`,
  )
}

export function getAccountPublishOptionValues(
  apiBase: string,
  apiKey: string,
  accountId: string,
  field: string,
  params?: Record<string, string>,
) {
  const query = new URLSearchParams(params)
  const suffix = query.size > 0 ? `?${query.toString()}` : ''

  return requestApi<PublishOptionValues>(
    apiBase,
    apiKey,
    `/v2/channels/accounts/${encodeURIComponent(accountId)}/publish-options/${encodeURIComponent(field)}/values${suffix}`,
  )
}

export function createUploadSign(apiBase: string, apiKey: string, file: File) {
  return requestApi<UploadSignData>(apiBase, apiKey, '/assets/uploadSign', {
    method: 'POST',
    body: JSON.stringify({
      filename: file.name,
      size: file.size,
      type: 'publishMedia',
    }),
  })
}

export function confirmAsset(apiBase: string, apiKey: string, assetId: string) {
  return requestApi<AssetVo>(apiBase, apiKey, `/assets/${encodeURIComponent(assetId)}/confirm`, {
    method: 'POST',
    body: JSON.stringify({ id: assetId }),
  })
}

export function createPublishFlow(apiBase: string, apiKey: string, payload: ChannelCreatePublishFlowParams) {
  return requestApi<ChannelPublishFlow>(apiBase, apiKey, '/v2/channels/publish/flows', {
    method: 'POST',
    body: JSON.stringify(payload),
  })
}

export function getPublishFlow(apiBase: string, apiKey: string, flowId: string) {
  return requestApi<ChannelPublishFlow>(
    apiBase,
    apiKey,
    `/v2/channels/publish/flows/${encodeURIComponent(flowId)}`,
  )
}

export function getPublishRecord(apiBase: string, apiKey: string, recordId: string) {
  return requestApi<ChannelPublishRecord>(
    apiBase,
    apiKey,
    `/v2/channels/publish/records/${encodeURIComponent(recordId)}`,
  )
}

export function getPublishUserAction(apiBase: string, apiKey: string, recordId: string) {
  return requestApi<ChannelPublishUserAction>(
    apiBase,
    apiKey,
    `/v2/channels/publish/records/${encodeURIComponent(recordId)}/user-action`,
  )
}

export async function uploadPublishFile(
  apiBase: string,
  apiKey: string,
  file: File,
  onProgress: (progress: number) => void,
) {
  const sign = await createUploadSign(apiBase, apiKey, file)
  const uploadUrl = sign.uploadUrl || sign.url

  await uploadToObjectStorage(uploadUrl, sign.uploadFields, file, onProgress)
  const asset = await confirmAsset(apiBase, apiKey, sign.id)

  return asset.url || sign.url
}

function uploadToObjectStorage(
  uploadUrl: string,
  uploadFields: Record<string, string> | undefined,
  file: File,
  onProgress: (progress: number) => void,
) {
  return new Promise<void>((resolve, reject) => {
    const xhr = new XMLHttpRequest()
    const proxyUrl = `/upload-proxy?target=${encodeURIComponent(uploadUrl)}`

    xhr.upload.addEventListener('progress', (event) => {
      if (event.lengthComputable) {
        onProgress(Math.round((event.loaded / event.total) * 100))
      }
    })

    xhr.addEventListener('load', () => {
      if (xhr.status >= 200 && xhr.status < 300) {
        onProgress(100)
        resolve()
      }
      else {
        reject(new Error(getUploadErrorMessage(xhr)))
      }
    })

    xhr.addEventListener('error', () => reject(new Error('上传失败: 网络错误')))

    const fieldEntries = Object.entries(uploadFields || {})
    if (fieldEntries.length > 0) {
      const formData = new FormData()
      fieldEntries.forEach(([key, value]) => formData.append(key, value))
      formData.append('file', file)
      xhr.open('POST', proxyUrl)
      xhr.send(formData)
      return
    }

    xhr.open('PUT', proxyUrl)
    xhr.setRequestHeader('Content-Type', file.type || 'application/octet-stream')
    xhr.send(file)
  })
}

function getUploadErrorMessage(xhr: XMLHttpRequest) {
  const status = xhr.status || 'unknown'
  const detail = xhr.responseText.trim()

  if (!detail) {
    return `上传失败: ${status}`
  }

  return `上传失败: ${status} ${detail.slice(0, 240)}`
}
